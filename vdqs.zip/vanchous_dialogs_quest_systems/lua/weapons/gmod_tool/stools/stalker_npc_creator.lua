TOOL.Category = "STALKER"
TOOL.Name = "#tool.stalker_npc_creator.name"
TOOL.Command = nil
TOOL.ConfigName = ""

-- СОСАТЬ
TOOL.ClientConVar["npc_name"] = "Сталкер"
TOOL.ClientConVar["npc_model"] = "models/humans/group01/male_01.mdl"
TOOL.ClientConVar["npc_behavior"] = "stand"
TOOL.ClientConVar["npc_immortal"] = "0"
TOOL.ClientConVar["npc_frozen"] = "0"
TOOL.ClientConVar["npc_trader"] = "0"

if CLIENT then
    language.Add("tool.stalker_npc_creator.name", "STALKER NPC Creator")
    language.Add("tool.stalker_npc_creator.desc", "Создание NPC с диалогами в стиле S.T.A.L.K.E.R.")
    language.Add("tool.stalker_npc_creator.0", "ЛКМ - Создать NPC | ПКМ - Настроить | Shift+ЛКМ - Дублировать | R - Удалить")
end

function TOOL:LeftClick(trace)
    if CLIENT then return true end

    local ply = self:GetOwner()
    if !IsValid(ply) then return false end

    if ply:KeyDown(IN_SPEED) then
        local ent = trace.Entity
        if IsValid(ent) and ent:GetClass() == "stalker_npc" then
            local pos = trace.HitPos + Vector(0, 0, 5)
            local ang = ent:GetAngles()

            local newNPC = StalkerSave:DuplicateNPC(ent, pos, ang)
            if IsValid(newNPC) then
                undo.Create("STALKER NPC (копия)")
                    undo.AddEntity(newNPC)
                    undo.SetPlayer(ply)
                undo.Finish()

                ply:ChatPrint("[STALKER] NPC '" .. ent:GetNPCName() .. "' дублирован!")
            end
            return true
        else
            ply:ChatPrint("[STALKER] Наведите на STALKER NPC для дублирования!")
            return false
        end
    end

    local name = self:GetClientInfo("npc_name")
    local model = self:GetClientInfo("npc_model")
    local behavior = self:GetClientInfo("npc_behavior")
    local immortal = self:GetClientNumber("npc_immortal") == 1
    local frozen = self:GetClientNumber("npc_frozen") == 1
    local trader = self:GetClientNumber("npc_trader") == 1

    if !util.IsValidModel(model) then
        ply:ChatPrint("[STALKER] Невалидная модель: " .. model)
        return false
    end

    local npc = ents.Create("stalker_npc")
    if !IsValid(npc) then return false end

    npc:SetNPCName(name)
    npc:SetNPCModel(model)
    npc:SetBehaviorType(behavior)
    npc:SetIsImmortal(immortal)
    npc:SetIsFrozen(frozen)
    npc:SetIsTrader(trader)

    npc:SetPos(trace.HitPos + Vector(0, 0, 5))
    local ang = (ply:GetPos() - trace.HitPos):Angle()
    npc:SetAngles(Angle(0, ang.y, 0))

    npc:Spawn()
    npc:Activate()

    undo.Create("STALKER NPC")
        undo.AddEntity(npc)
        undo.SetPlayer(ply)
    undo.Finish()

    ply:ChatPrint("[STALKER] NPC '" .. name .. "' создан!")
    return true
end

function TOOL:RightClick(trace)
    if CLIENT then return true end

    local ent = trace.Entity
    if !IsValid(ent) or ent:GetClass() != "stalker_npc" then
        self:GetOwner():ChatPrint("[STALKER] Это не STALKER NPC!")
        return false
    end

    local npcData = {
        dialogs = ent.Dialogs or {},
        quests = ent.QuestGiver or {},
        trade_items = ent.TradeItems or {}
    }

    local json = util.TableToJSON(npcData)

    net.Start("stalker_open_editor")
        net.WriteEntity(ent)
        net.WriteString(ent:GetNPCName() or "NPC")
        net.WriteUInt(#json, 32)
        net.WriteData(json, #json)
    net.Send(self:GetOwner())

    return true
end

function TOOL:Reload(trace)
    if CLIENT then return true end

    local ent = trace.Entity
    if IsValid(ent) and ent:GetClass() == "stalker_npc" then
        ent:Remove()
        self:GetOwner():ChatPrint("[STALKER] NPC удалён!")
        return true
    end
    return false
end

function TOOL.BuildCPanel(panel)
    panel:AddControl("Header", {Description = "S.T.A.L.K.E.R. NPC System v1.2\nЛКМ - Создать NPC\nShift+ЛКМ (на NPC) - Дублировать\nПКМ (на NPC) - Настроить\nR (на NPC) - Удалить"})

    panel:AddControl("TextBox", {
        Label = "Имя NPC:",
        Command = "stalker_npc_creator_npc_name",
        MaxLength = 64
    })

    panel:AddControl("TextBox", {
        Label = "Модель (путь):",
        Command = "stalker_npc_creator_npc_model",
        MaxLength = 256
    })

    panel:AddControl("ComboBox", {
        Label = "Поведение:",
        MenuButton = 0,
        Options = {
            ["Стоит"] = {stalker_npc_creator_npc_behavior = "stand"},
            ["Ходит"] = {stalker_npc_creator_npc_behavior = "walk"},
            ["Сидит"] = {stalker_npc_creator_npc_behavior = "sit"},
            ["Охраняет"] = {stalker_npc_creator_npc_behavior = "guard"},
        }
    })

    panel:AddControl("CheckBox", {
        Label = "Бессмертный",
        Command = "stalker_npc_creator_npc_immortal"
    })

    panel:AddControl("CheckBox", {
        Label = "Заморозить",
        Command = "stalker_npc_creator_npc_frozen"
    })

    panel:AddControl("CheckBox", {
        Label = "Торговец",
        Command = "stalker_npc_creator_npc_trader"
    })

    panel:AddControl("Header", {Description = "=== Сохранение NPC ==="})

    panel:AddControl("Button", {
        Label = "Сохранить всех NPC на карте",
        Command = "stalker_save_npcs"
    })

    panel:AddControl("Button", {
        Label = "Загрузить NPC",
        Command = "stalker_load_npcs"
    })

    panel:AddControl("Button", {
        Label = "Создать бэкап",
        Command = "stalker_backup"
    })

    panel:AddControl("Button", {
        Label = "Удалить всех NPC",
        Command = "stalker_clear_npcs"
    })
end