if SERVER then
    AddCSLuaFile()
    AddCSLuaFile("stalker/cl_dialog_ui.lua")
    AddCSLuaFile("stalker/cl_npc_editor.lua")
    AddCSLuaFile("stalker/cl_quest_hud.lua")
    AddCSLuaFile("stalker/cl_trade_ui.lua")
    AddCSLuaFile("stalker/cl_money_hud.lua")

    include("stalker/sv_money_system.lua")
    include("stalker/sv_save_system.lua")
    include("stalker/sv_dialog_system.lua")
    include("stalker/sv_quest_system.lua")
    include("stalker/sv_trade_system.lua")

    util.AddNetworkString("stalker_open_dialog")
    util.AddNetworkString("stalker_close_dialog")
    util.AddNetworkString("stalker_select_option")
    util.AddNetworkString("stalker_npc_setup")
    util.AddNetworkString("stalker_npc_set_dialogs")
    util.AddNetworkString("stalker_quest_update")
    util.AddNetworkString("stalker_quest_notify")
    util.AddNetworkString("stalker_open_editor")
    util.AddNetworkString("stalker_request_npc_data")
    util.AddNetworkString("stalker_npc_data_response")
    util.AddNetworkString("stalker_save_dialogs")
    util.AddNetworkString("stalker_quest_complete")
    util.AddNetworkString("stalker_quest_start")
    util.AddNetworkString("stalker_open_trade")
    util.AddNetworkString("stalker_close_trade")
    util.AddNetworkString("stalker_buy_item")
    util.AddNetworkString("stalker_sell_item")
    util.AddNetworkString("stalker_trade_result")
    util.AddNetworkString("stalker_save_trade_data")
    util.AddNetworkString("stalker_trade_data_update")
    util.AddNetworkString("stalker_money_sync")
    util.AddNetworkString("stalker_money_transfer_request")
    util.AddNetworkString("stalker_money_received")
end

if CLIENT then
    include("stalker/cl_dialog_ui.lua")
    include("stalker/cl_npc_editor.lua")
    include("stalker/cl_quest_hud.lua")
    include("stalker/cl_trade_ui.lua")
    include("stalker/cl_money_hud.lua")
end

StalkerSystem = StalkerSystem or {}
StalkerSystem.NPCData = StalkerSystem.NPCData or {}
StalkerSystem.Version = "1.2"

if SERVER then
    timer.Simple(1, function()
        if !nMoneyServerSettings then
            print("[STALKER] !!! ЗАВИСИМОСТЬ НЕ НАЙДЕНА: требуется аддон nMoney (денежная база). !!!")
        end
    end)
end

print("VANCHOUS QUETS SYSTEM LOADED!")