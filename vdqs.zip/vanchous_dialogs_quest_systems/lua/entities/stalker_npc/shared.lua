ENT.Type = "ai"
ENT.Base = "base_ai"
ENT.PrintName = "STALKER NPC"
ENT.Author = "STALKER System"
ENT.Category = "STALKER"
ENT.Spawnable = false
ENT.AdminSpawnable = false
ENT.AutomaticFrameAdvance = true

function ENT:SetupDataTables()
    self:NetworkVar("String", 0, "NPCName")
    self:NetworkVar("String", 1, "NPCModel")
    self:NetworkVar("String", 2, "BehaviorType")
    self:NetworkVar("Bool", 0, "IsImmortal")
    self:NetworkVar("Bool", 1, "IsFrozen")
    self:NetworkVar("Bool", 2, "IsTrader")
    self:NetworkVar("Int", 0, "NPCUniqueID")
end