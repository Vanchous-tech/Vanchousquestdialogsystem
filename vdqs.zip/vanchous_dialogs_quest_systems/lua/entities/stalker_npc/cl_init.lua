include("shared.lua")

function ENT:Draw()
    self:DrawModel()

    local pos = self:GetPos() + Vector(0, 0, 80)
    local ang = LocalPlayer():EyeAngles()
    local dist = LocalPlayer():GetPos():Distance(self:GetPos())

    if dist < 300 then
        ang:RotateAroundAxis(ang:Up(), -90)
        ang:RotateAroundAxis(ang:Forward(), 90)

        cam.Start3D2D(pos, ang, 0.15)
            local name = self:GetNPCName() or "NPC"
            draw.SimpleTextOutlined(name, "DermaLarge", 0, 0, Color(255, 220, 100), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 2, Color(0, 0, 0))

            if dist < 150 then
                local hint = "[E] Поговорить"
                if self:GetIsTrader() then
                    hint = "[E] Поговорить / Торговать"
                end
                draw.SimpleTextOutlined(hint, "DermaDefault", 0, 30, Color(200, 200, 200), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0))
            end
        cam.End3D2D()
    end
end