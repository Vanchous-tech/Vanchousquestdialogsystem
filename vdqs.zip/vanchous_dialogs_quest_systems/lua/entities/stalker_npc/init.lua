AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:Initialize()
    local mdl = self:GetNPCModel()
    if !mdl or mdl == "" then mdl = "models/humans/group01/male_01.mdl" end

    self:SetModel(mdl)
    self:SetHullType(HULL_HUMAN)
    self:SetHullSizeNormal()
    self:SetSolid(SOLID_BBOX)
    self:SetMoveType(MOVETYPE_STEP)
    self:CapabilitiesAdd(CAP_ANIMATEDFACE + CAP_TURN_HEAD)
    self:SetUseType(SIMPLE_USE)
    self:SetMaxYawSpeed(5000)
    self:SetHealth(100)

    self.Dialogs = self.Dialogs or {}
    self.QuestGiver = self.QuestGiver or {}
    self.TradeItems = self.TradeItems or {}

    self:SetNPCUniqueID(self:EntIndex())

    timer.Simple(0.1, function()
        if IsValid(self) then
            self:ApplyBehavior()
        end
    end)
end

function ENT:ApplyBehavior()
    local behavior = self:GetBehaviorType()
    if behavior == "stand" or behavior == "" then
        self:SetSchedule(SCHED_IDLE_STAND)
        self.BehaviorMode = "stand"
    elseif behavior == "walk" then
        self:CapabilitiesAdd(CAP_MOVE_GROUND)
        self:SetSchedule(SCHED_IDLE_WALK)
        self.BehaviorMode = "walk"
    elseif behavior == "sit" then
        local seq = self:LookupSequence("idle_to_sit_ground")
        if seq and seq >= 0 then
            self:SetSequence(seq)
            self:SetCycle(1)
        end
        self.BehaviorMode = "sit"
    elseif behavior == "guard" then
        self:SetSchedule(SCHED_ALERT_STAND)
        self.BehaviorMode = "guard"
    end
end

function ENT:SelectSchedule()
    local behavior = self.BehaviorMode or "stand"
    if behavior == "stand" then
        self:SetSchedule(SCHED_IDLE_STAND)
    elseif behavior == "walk" then
        self:SetSchedule(SCHED_IDLE_WALK)
    elseif behavior == "guard" then
        self:SetSchedule(SCHED_ALERT_STAND)
    end
end

function ENT:OnTakeDamage(dmginfo)
    if self:GetIsImmortal() then return 0 end
    self:SetHealth(self:Health() - dmginfo:GetDamage())
    if self:Health() <= 0 then
        self:SetSchedule(SCHED_DIE)
        timer.Simple(3, function()
            if IsValid(self) then self:Remove() end
        end)
    end
end

function ENT:AcceptInput(inputName, activator, caller)
    if inputName == "Use" and IsValid(caller) and caller:IsPlayer() then
        self:OpenDialog(caller)
        return true
    end
    return false
end

function ENT:Use(activator, caller, useType, value)
    local ply = activator
    if !IsValid(ply) or !ply:IsPlayer() then ply = caller end
    if IsValid(ply) and ply:IsPlayer() then
        self:OpenDialog(ply)
    end
end

function ENT:OpenDialog(ply)
    if !self.Dialogs or table.Count(self.Dialogs) == 0 then
        if self:GetIsTrader() then
            self:OpenTrade(ply)
            return
        end

        self.Dialogs = {
            root = {
                npc_text = "Привет, сталкер.",
                options = {
                    {text = "До встречи.", next = "exit"}
                }
            }
        }
    end

    -- Увеличиваем счётчик разговоров
    StalkerDialogs:IncrementTalkCount(ply, self)

    -- Фильтруем диалоги по условиям
    local filteredDialogs = StalkerDialogs:FilterDialogs(self.Dialogs, ply, self)

    -- Добавляем кнопку торговли если торговец
    if self:GetIsTrader() then
        local rootNode = filteredDialogs["root"]
        if rootNode then
            local hasTradeOption = false
            for _, opt in ipairs(rootNode.options or {}) do
                if opt.next == "open_trade" then
                    hasTradeOption = true
                    break
                end
            end
            if !hasTradeOption then
                table.insert(rootNode.options, 1, {text = "Торговать", next = "open_trade"})
            end
        end
    end

    local startNode = "root"
    if !filteredDialogs[startNode] then
        for nodeID, _ in pairs(filteredDialogs) do
            startNode = nodeID
            break
        end
    end

    local dialogJSON = util.TableToJSON(filteredDialogs)

    -- Отправляем счётчик разговоров клиенту
    local history = StalkerDialogs:GetHistory(ply, self)

    net.Start("stalker_open_dialog")
        net.WriteEntity(self)
        net.WriteString(self:GetNPCName() or "NPC")
        net.WriteString(startNode)
        net.WriteUInt(history.talk_count, 16)
        net.WriteUInt(#dialogJSON, 32)
        net.WriteData(dialogJSON, #dialogJSON)
    net.Send(ply)

    local ang = (ply:GetPos() - self:GetPos()):Angle()
    self:SetAngles(Angle(0, ang.y, 0))
end

function ENT:OpenTrade(ply)
    if !self:GetIsTrader() then return end

    local tradeJSON = util.TableToJSON(self.TradeItems or {})

    net.Start("stalker_open_trade")
        net.WriteEntity(self)
        net.WriteString(self:GetNPCName() or "Торговец")
        net.WriteUInt(#tradeJSON, 32)
        net.WriteData(tradeJSON, #tradeJSON)
    net.Send(ply)
end

function ENT:SetDialogData(data)
    self.Dialogs = data
end

function ENT:SetQuestData(data)
    self.QuestGiver = data
end

function ENT:SetTradeData(data)
    self.TradeItems = data
end

function ENT:Think()
    if self:GetIsFrozen() then
        self:SetMoveType(MOVETYPE_NONE)
    end
    self:NextThink(CurTime() + 0.1)
    return true
end