-- Вот скажи, зачем тебе это? Без моего копирайта я тебе ебальник набью

StalkerQuestHUD = StalkerQuestHUD or {}
StalkerQuestHUD.ActiveQuests = StalkerQuestHUD.ActiveQuests or {}
StalkerQuestHUD.Notifications = StalkerQuestHUD.Notifications or {}

surface.CreateFont("StalkerQuestTitle", {
    font = "Arial",
    size = 16,
    weight = 700,
    antialias = true,
})

surface.CreateFont("StalkerQuestText", {
    font = "Arial",
    size = 13,
    weight = 500,
    antialias = true,
})

surface.CreateFont("StalkerQuestNotify", {
    font = "Arial",
    size = 20,
    weight = 700,
    antialias = true,
})

hook.Add("HUDPaint", "StalkerQuestHUDPaint", function()
    local quests = StalkerQuestHUD.ActiveQuests
    if table.Count(quests) == 0 then return end

    local x = ScrW() - 320
    local y = 60
    local w = 300
    local padding = 8

    surface.SetDrawColor(20, 18, 15, 200)
    surface.DrawRect(x, y, w, 26)
    surface.SetDrawColor(120, 100, 60, 180)
    surface.DrawOutlinedRect(x, y, w, 26, 1)
    draw.SimpleText("ЗАДАНИЯ", "StalkerQuestTitle", x + w / 2, y + 13, Color(255, 200, 80), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

    y = y + 30

    for questID, quest in pairs(quests) do
        local questH = 24 + (#(quest.objectives or {}) * 18) + 8

        surface.SetDrawColor(20, 18, 15, 180)
        surface.DrawRect(x, y, w, questH)
        surface.SetDrawColor(100, 85, 50, 150)
        surface.DrawOutlinedRect(x, y, w, questH, 1)

        draw.SimpleText(quest.title or questID, "StalkerQuestTitle", x + padding, y + 4, Color(220, 200, 140))

        local objY = y + 24
        if quest.objectives then
            for i, obj in ipairs(quest.objectives) do
                local color = obj.completed and Color(100, 200, 100) or Color(200, 190, 170)
                local prefix = obj.completed and "✓ " or "• "
                local progress = ""
                if obj.required and obj.required > 1 then
                    progress = " [" .. (obj.current or 0) .. "/" .. obj.required .. "]"
                end
                draw.SimpleText(prefix .. (obj.description or "???") .. progress, "StalkerQuestText", x + padding + 8, objY, color)
                objY = objY + 18
            end
        end

        y = y + questH + 4
    end

    local notifs = StalkerQuestHUD.Notifications
    local removeList = {}

    for i, notif in ipairs(notifs) do
        local elapsed = CurTime() - notif.time
        local alpha = 255

        if elapsed > notif.duration - 1 then
            alpha = 255 * (1 - (elapsed - (notif.duration - 1)))
        end

        if elapsed > notif.duration then
            table.insert(removeList, i)
        else
            local ny = ScrH() * 0.25 + (i - 1) * 40
            local nw = 400

            surface.SetDrawColor(20, 18, 15, alpha * 0.85)
            surface.DrawRect(ScrW() / 2 - nw / 2, ny, nw, 36)
            surface.SetDrawColor(120, 100, 60, alpha * 0.7)
            surface.DrawOutlinedRect(ScrW() / 2 - nw / 2, ny, nw, 36, 1)

            draw.SimpleText(notif.text, "StalkerQuestNotify", ScrW() / 2, ny + 18, ColorAlpha(notif.color or Color(255, 220, 100), alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    end

    for i = #removeList, 1, -1 do
        table.remove(notifs, removeList[i])
    end
end)

net.Receive("stalker_quest_start", function()
    local questID = net.ReadString()
    local title = net.ReadString()
    local description = net.ReadString()

    StalkerQuestHUD.ActiveQuests[questID] = {
        title = title,
        description = description,
        objectives = {},
    }

    table.insert(StalkerQuestHUD.Notifications, {
        text = "Новый квест: " .. title,
        color = Color(255, 220, 80),
        time = CurTime(),
        duration = 5
    })

    surface.PlaySound("ui/buttonclickrelease.wav")
end)

net.Receive("stalker_quest_update", function()
    local questID = net.ReadString()
    local objIndex = net.ReadUInt(8)
    local current = net.ReadUInt(16)
    local required = net.ReadUInt(16)
    local completed = net.ReadBool()
    local description = net.ReadString()

    if !StalkerQuestHUD.ActiveQuests[questID] then
        StalkerQuestHUD.ActiveQuests[questID] = {
            title = questID,
            objectives = {}
        }
    end

    StalkerQuestHUD.ActiveQuests[questID].objectives[objIndex] = {
        current = current,
        required = required,
        completed = completed,
        description = description
    }

    if completed then
        table.insert(StalkerQuestHUD.Notifications, {
            text = "Цель выполнена!",
            color = Color(100, 255, 100),
            time = CurTime(),
            duration = 3
        })
    end
end)

net.Receive("stalker_quest_complete", function()
    local questID = net.ReadString()
    local title = net.ReadString()

    StalkerQuestHUD.ActiveQuests[questID] = nil

    table.insert(StalkerQuestHUD.Notifications, {
        text = "Квест выполнен: " .. title,
        color = Color(80, 255, 80),
        time = CurTime(),
        duration = 5
    })

    surface.PlaySound("ui/buttonclickrelease.wav")
end)