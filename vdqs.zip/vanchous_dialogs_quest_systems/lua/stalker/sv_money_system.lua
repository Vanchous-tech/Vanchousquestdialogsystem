-- StalkerMoney теперь просто обёртка (bridge) над nMoney.
-- Вся денежная база (хранение, файлы сохранений, кэпы баланса) отдана на откуп nMoney.
-- Интерфейс StalkerMoney:Get/Set/Add/Take/Has/SyncToClient сохранён без изменений,
-- поэтому sv_dialog_system.lua, sv_quest_system.lua, sv_trade_system.lua и HUD
-- продолжают работать без единой правки.

StalkerMoney = StalkerMoney or {}

-- ===================== ПРОВЕРКА ЗАВИСИМОСТИ =====================

local function EnsureNMoney()
    if !nMoneyServerSettings then
        -- nMoney ещё не успел проинициализироваться (порядок autorun не гарантирован)
        -- или не установлен вовсе. Подставляем безопасные дефолты, чтобы аддон не упал.
        nMoneyServerSettings = nMoneyServerSettings or {
            WALLET_START_MONEY = 0,
            MAX_WALLET_MONEY = 5000,
        }
        return false
    end
    return true
end

hook.Add("Initialize", "StalkerMoney_CheckNMoneyDependency", function()
    timer.Simple(1, function()
        if !nMoneyServerSettings then
            print("[STALKER Money] ВНИМАНИЕ: nMoney не найден! Убедитесь, что аддон nMoney установлен и загружается.")
        else
            print("[STALKER Money] nMoney обнаружен, денежная база подключена.")
        end
    end)
end)

-- ===================== ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ =====================

local function SteamIDPath(ply)
    -- nMoney использует ply:SteamID() (не SteamID64!) с вырезанными двоеточиями
    return string.Replace(ply:SteamID(), ":", "")
end

local function SaveWalletToDisk(ply)
    if ply:IsBot() then return end
    file.CreateDir("nmoney2/wallet")
    file.Write("nmoney2/wallet/" .. SteamIDPath(ply) .. ".txt", ply:GetNWString("WalletMoney", "0"))
end

-- ===================== ОСНОВНОЙ API (совместим со старым StalkerMoney) =====================

function StalkerMoney:Get(ply)
    if !IsValid(ply) then return 0 end
    return tonumber(ply:GetNWString("WalletMoney", "0")) or 0
end

function StalkerMoney:Set(ply, amount)
    if !IsValid(ply) then return end
    EnsureNMoney()

    amount = math.max(0, math.floor(amount))

    local cap = nMoneyServerSettings.MAX_WALLET_MONEY
    if cap then
        amount = math.min(amount, cap)
    end
    amount = math.min(amount, NMONEY2_MAXVALUE or amount)

    ply:SetNWString("WalletMoney", tostring(amount))
    SaveWalletToDisk(ply)
    self:SyncToClient(ply)
end

function StalkerMoney:Add(ply, amount)
    if !IsValid(ply) then return end
    local current = self:Get(ply)
    self:Set(ply, current + amount)
end

--ТИХО СПИЗДИЛ И УШЁЛ - НАЗЫВАЕТСЯ НАШЁЛ
function StalkerMoney:Take(ply, amount)
    if !IsValid(ply) then return false end
    local current = self:Get(ply)
    if current < amount then return false end
    self:Set(ply, current - amount)
    return true
end

function StalkerMoney:Has(ply, amount)
    return self:Get(ply) >= amount
end

function StalkerMoney:SyncToClient(ply)
    if !IsValid(ply) then return end
    local money = self:Get(ply)

    net.Start("stalker_money_sync")
        net.WriteUInt(money, 32)
    net.Send(ply)
end

-- ===================== СЕТЕВЫЕ ХУКИ / КОМАНДЫ (без изменений в поведении) =====================

hook.Add("PlayerInitialSpawn", "StalkerMoneyInit", function(ply)
    timer.Simple(2, function()
        if !IsValid(ply) then return end
        EnsureNMoney()

        StalkerMoney:SyncToClient(ply)
        ply:ChatPrint("[STALKER] Ваш баланс: " .. StalkerMoney:Get(ply) .. " RU")
    end)
end)

net.Receive("stalker_money_transfer_request", function(len, ply)
    local target = net.ReadEntity()
    local amount = net.ReadUInt(32)

    if !IsValid(target) or !target:IsPlayer() then
        ply:ChatPrint("[STALKER] Игрок не найден!")
        return
    end

    if target == ply then
        ply:ChatPrint("[STALKER] Нельзя передать деньги самому себе!")
        return
    end

    if ply:GetPos():Distance(target:GetPos()) > 300 then
        ply:ChatPrint("[STALKER] Игрок слишком далеко!")
        return
    end

    if amount <= 0 then
        ply:ChatPrint("[STALKER] Неверная сумма!")
        return
    end

    if !StalkerMoney:Has(ply, amount) then
        ply:ChatPrint("[STALKER] Недостаточно денег! У вас: " .. StalkerMoney:Get(ply))
        return
    end

    StalkerMoney:Take(ply, amount)
    StalkerMoney:Add(target, amount)

    ply:ChatPrint("[STALKER] Передано " .. amount .. " RU игроку " .. target:Nick())
    target:ChatPrint("[STALKER] " .. ply:Nick() .. " передал вам " .. amount .. " RU")

    net.Start("stalker_money_received")
        net.WriteEntity(ply)
        net.WriteUInt(amount, 32)
    net.Send(target)
end)

concommand.Add("stalker_give_money", function(ply, cmd, args)
    if !IsValid(ply) then
        local target = player.GetByID(tonumber(args[2]) or 1)
        local amount = tonumber(args[1]) or 1000
        if IsValid(target) then
            StalkerMoney:Add(target, amount)
            print("[STALKER] Выдано " .. amount .. " RU игроку " .. target:Nick())
        end
        return
    end

    if !ply:IsAdmin() then
        ply:ChatPrint("[STALKER] Только для админов!")
        return
    end

    local amount = tonumber(args[1]) or 1000
    local target = ply

    if args[2] then
        local name = args[2]
        for _, p in ipairs(player.GetAll()) do
            if string.find(string.lower(p:Nick()), string.lower(name)) then
                target = p
                break
            end
        end
    end

    StalkerMoney:Add(target, amount)
    ply:ChatPrint("[STALKER] Выдано " .. amount .. " RU для " .. target:Nick())
    ply:ChatPrint("[STALKER] Баланс " .. target:Nick() .. ": " .. StalkerMoney:Get(target) .. " RU")
end)

concommand.Add("stalker_set_money", function(ply, cmd, args)
    if IsValid(ply) and !ply:IsAdmin() then
        ply:ChatPrint("[STALKER] Только для админов!")
        return
    end

    local amount = tonumber(args[1]) or 0
    local target = ply

    if args[2] then
        local name = args[2]
        for _, p in ipairs(player.GetAll()) do
            if string.find(string.lower(p:Nick()), string.lower(name)) then
                target = p
                break
            end
        end
    end

    if !IsValid(target) then return end

    StalkerMoney:Set(target, amount)
    if IsValid(ply) then
        ply:ChatPrint("[STALKER] Установлено " .. amount .. " RU для " .. target:Nick())
    end
end)

concommand.Add("stalker_balance", function(ply)
    if !IsValid(ply) then return end
    ply:ChatPrint("[STALKER] Ваш баланс: " .. StalkerMoney:Get(ply) .. " RU")
end)

print("[STALKER Money] Мост StalkerMoney -> nMoney загружен!")
