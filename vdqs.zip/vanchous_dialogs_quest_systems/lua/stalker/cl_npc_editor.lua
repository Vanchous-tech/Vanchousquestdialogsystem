-- Редактор диалогов, квестов и торговли NPC

StalkerEditor = StalkerEditor or {}
StalkerEditor.Panel = nil

surface.CreateFont("StalkerEditorTitle", {
    font = "Arial", size = 18, weight = 700, antialias = true,
})
surface.CreateFont("StalkerEditorText", {
    font = "Arial", size = 14, weight = 500, antialias = true,
})

local EDITOR_COLORS = {
    bg = Color(30, 28, 25),
    panel = Color(40, 36, 30),
    border = Color(120, 100, 60),
    accent = Color(200, 170, 80),
    text = Color(220, 210, 190),
    button = Color(60, 52, 38),
    button_hover = Color(80, 70, 50),
    input_bg = Color(25, 22, 18),
    red = Color(200, 60, 60),
    green = Color(60, 200, 60),
}

local function PaintInputBg(pnl, w, h)
    surface.SetDrawColor(EDITOR_COLORS.input_bg)
    surface.DrawRect(0, 0, w, h)
    surface.SetDrawColor(EDITOR_COLORS.border)
    surface.DrawOutlinedRect(0, 0, w, h, 1)
    pnl:DrawTextEntryText(EDITOR_COLORS.text, EDITOR_COLORS.accent, EDITOR_COLORS.text)
end

local function PaintButton(pnl, w, h)
    surface.SetDrawColor(pnl:IsHovered() and EDITOR_COLORS.button_hover or EDITOR_COLORS.button)
    surface.DrawRect(0, 0, w, h)
end

function StalkerEditor:Open(npc, npcName, existingData)
    self:Close()

    self.NPC = npc
    self.NPCName = npcName
    self.DialogNodes = existingData.dialogs or {
        root = {
            npc_text = "Привет, сталкер.",
            options = {
                {text = "Привет.", next = "exit"}
            }
        }
    }
    self.Quests = existingData.quests or {}
    self.TradeItems = existingData.trade_items or {}

    local scrW, scrH = ScrW(), ScrH()

    self.Panel = vgui.Create("DFrame")
    self.Panel:SetSize(scrW * 0.75, scrH * 0.8)
    self.Panel:Center()
    self.Panel:MakePopup()
    self.Panel:SetTitle("STALKER Editor — " .. npcName)
    self.Panel:SetDraggable(true)
    self.Panel:SetSizable(true)
    self.Panel.Paint = function(pnl, w, h)
        surface.SetDrawColor(EDITOR_COLORS.bg)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(EDITOR_COLORS.border)
        surface.DrawOutlinedRect(0, 0, w, h, 2)

        surface.SetDrawColor(EDITOR_COLORS.panel)
        surface.DrawRect(0, 0, w, 28)
        draw.SimpleText("STALKER NPC Editor — " .. npcName, "StalkerEditorTitle", w / 2, 14, EDITOR_COLORS.accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    self.Panel.btnClose.Paint = function(pnl2, w2, h2)
        draw.SimpleText("X", "StalkerEditorTitle", w2/2, h2/2, pnl2:IsHovered() and EDITOR_COLORS.red or EDITOR_COLORS.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    self.Panel.btnMaxim:SetVisible(false)
    self.Panel.btnMinim:SetVisible(false)
    self.Panel.lblTitle:SetVisible(false)

    local tabs = vgui.Create("DPropertySheet", self.Panel)
    tabs:Dock(FILL)
    tabs:DockMargin(4, 4, 4, 4)
    tabs.Paint = function(pnl, w, h)
        surface.SetDrawColor(EDITOR_COLORS.bg)
        surface.DrawRect(0, 0, w, h)
    end

    -- Вкладка диалогов
    local dialogTab = self:BuildDialogTab(tabs)
    tabs:AddSheet("Диалоги", dialogTab, "icon16/comments.png")

    -- Вкладка квестов
    local questTab = self:BuildQuestTab(tabs)
    tabs:AddSheet("Квесты", questTab, "icon16/flag_green.png")

    -- Вкладка торговли (если NPC торговец)
    if IsValid(self.NPC) and self.NPC:GetIsTrader() then
        local tradeTab = self:BuildTradeTab(tabs)
        tabs:AddSheet("Торговля", tradeTab, "icon16/money.png")
    end

    -- Кнопка сохранения
    local saveBtn = vgui.Create("DButton", self.Panel)
    saveBtn:Dock(BOTTOM)
    saveBtn:DockMargin(4, 4, 4, 4)
    saveBtn:SetTall(36)
    saveBtn:SetText("")
    saveBtn.Paint = function(pnl, w, h)
        surface.SetDrawColor(pnl:IsHovered() and Color(60, 120, 40) or Color(40, 90, 30))
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(EDITOR_COLORS.border)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
        draw.SimpleText("СОХРАНИТЬ", "StalkerEditorTitle", w / 2, h / 2, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    saveBtn.DoClick = function()
        self:Save()
    end
end

function StalkerEditor:BuildDialogTab(parent)
    local panel = vgui.Create("DPanel", parent)
    panel.Paint = function(pnl, w, h)
        surface.SetDrawColor(EDITOR_COLORS.bg)
        surface.DrawRect(0, 0, w, h)
    end

    local leftPanel = vgui.Create("DPanel", panel)
    leftPanel:Dock(LEFT)
    leftPanel:SetWide(200)
    leftPanel:DockMargin(4, 4, 4, 4)
    leftPanel.Paint = function(pnl, w, h)
        surface.SetDrawColor(EDITOR_COLORS.panel)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(EDITOR_COLORS.border)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
        draw.SimpleText("Узлы диалога", "StalkerEditorText", w / 2, 10, EDITOR_COLORS.accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
    end

    local nodeList = vgui.Create("DListView", leftPanel)
    nodeList:Dock(FILL)
    nodeList:DockMargin(4, 28, 4, 4)
    nodeList:AddColumn("ID узла")
    nodeList:SetMultiSelect(false)
    nodeList:SetHeaderHeight(20)

    local rightPanel = vgui.Create("DPanel", panel)
    rightPanel:Dock(FILL)
    rightPanel:DockMargin(4, 4, 4, 4)
    rightPanel.Paint = function(pnl, w, h)
        surface.SetDrawColor(EDITOR_COLORS.panel)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(EDITOR_COLORS.border)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end

    local rightScroll = vgui.Create("DScrollPanel", rightPanel)
    rightScroll:Dock(FILL)
    rightScroll:DockMargin(4, 4, 4, 4)

    local editContainer = vgui.Create("DListLayout", rightScroll)
    editContainer:Dock(TOP)
    editContainer:DockMargin(4, 4, 4, 4)

    local function RefreshNodeList()
        nodeList:Clear()
        for nodeID, _ in pairs(self.DialogNodes) do
            nodeList:AddLine(nodeID)
        end
    end

    RefreshNodeList()

    local btnPanel = vgui.Create("DPanel", leftPanel)
    btnPanel:Dock(BOTTOM)
    btnPanel:SetTall(70)
    btnPanel:DockMargin(4, 0, 4, 4)
    btnPanel.Paint = function() end

    local addNodeBtn = vgui.Create("DButton", btnPanel)
    addNodeBtn:Dock(TOP)
    addNodeBtn:SetTall(30)
    addNodeBtn:DockMargin(0, 2, 0, 2)
    addNodeBtn:SetText("+ Добавить узел")
    addNodeBtn:SetTextColor(EDITOR_COLORS.text)
    addNodeBtn.Paint = PaintButton
    addNodeBtn.DoClick = function()
        Derma_StringRequest("Новый узел", "Введите ID узла:", "node_" .. table.Count(self.DialogNodes),
            function(text)
                if text == "" or self.DialogNodes[text] then
                    notification.AddLegacy("ID уже существует или пустой!", NOTIFY_ERROR, 3)
                    return
                end
                self.DialogNodes[text] = {
                    npc_text = "Текст NPC...",
                    options = {{text = "Вариант ответа", next = "exit"}}
                }
                RefreshNodeList()
            end)
    end

    local delNodeBtn = vgui.Create("DButton", btnPanel)
    delNodeBtn:Dock(TOP)
    delNodeBtn:SetTall(30)
    delNodeBtn:DockMargin(0, 2, 0, 2)
    delNodeBtn:SetText("- Удалить узел")
    delNodeBtn:SetTextColor(EDITOR_COLORS.red)
    delNodeBtn.Paint = PaintButton
    delNodeBtn.DoClick = function()
        local _, selected = nodeList:GetSelectedLine()
        if selected then
            local nodeID = selected:GetValue(1)
            if nodeID == "root" then
                notification.AddLegacy("Нельзя удалить корневой узел!", NOTIFY_ERROR, 3)
                return
            end
            self.DialogNodes[nodeID] = nil
            RefreshNodeList()
            editContainer:Clear()
        end
    end

    nodeList.OnRowSelected = function(lst, index, row)
        local nodeID = row:GetValue(1)
        self:EditNode(nodeID, editContainer, rightScroll, RefreshNodeList)
    end

    return panel
end

function StalkerEditor:EditNode(nodeID, container, scroll, refreshFunc)
    container:Clear()

    local node = self.DialogNodes[nodeID]
    if !node then return end

    local header = vgui.Create("DPanel", container)
    header:Dock(TOP)
    header:SetTall(30)
    header:DockMargin(4, 4, 4, 4)
    header.Paint = function(pnl, w, h)
        draw.SimpleText("Редактирование узла: " .. nodeID, "StalkerEditorTitle", 4, h / 2, EDITOR_COLORS.accent, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end

    local npcTextLabel = vgui.Create("DLabel", container)
    npcTextLabel:Dock(TOP)
    npcTextLabel:DockMargin(4, 8, 4, 2)
    npcTextLabel:SetText("Текст NPC:")
    npcTextLabel:SetTextColor(EDITOR_COLORS.text)
    npcTextLabel:SetFont("StalkerEditorText")

    local npcTextEntry = vgui.Create("DTextEntry", container)
    npcTextEntry:Dock(TOP)
    npcTextEntry:DockMargin(4, 0, 4, 4)
    npcTextEntry:SetTall(80)
    npcTextEntry:SetMultiline(true)
    npcTextEntry:SetValue(node.npc_text or "")
    npcTextEntry:SetTextColor(EDITOR_COLORS.text)
    npcTextEntry:SetCursorColor(EDITOR_COLORS.accent)
    npcTextEntry.Paint = PaintInputBg
    npcTextEntry.OnChange = function(pnl)
        node.npc_text = pnl:GetValue()
    end

    local questLabel = vgui.Create("DLabel", container)
    questLabel:Dock(TOP)
    questLabel:DockMargin(4, 4, 4, 2)
    questLabel:SetText("Запустить квест (ID, пусто = нет):")
    questLabel:SetTextColor(EDITOR_COLORS.text)
    questLabel:SetFont("StalkerEditorText")

    local questStartEntry = vgui.Create("DTextEntry", container)
    questStartEntry:Dock(TOP)
    questStartEntry:DockMargin(4, 0, 4, 4)
    questStartEntry:SetTall(24)
    questStartEntry:SetValue(node.quest_start or "")
    questStartEntry:SetTextColor(EDITOR_COLORS.text)
    questStartEntry:SetCursorColor(EDITOR_COLORS.accent)
    questStartEntry.Paint = PaintInputBg
    questStartEntry.OnChange = function(pnl)
        local val = pnl:GetValue()
        node.quest_start = val != "" and val or nil
    end

    local questCompleteLabel = vgui.Create("DLabel", container)
    questCompleteLabel:Dock(TOP)
    questCompleteLabel:DockMargin(4, 4, 4, 2)
    questCompleteLabel:SetText("Завершить квест (ID, пусто = нет):")
    questCompleteLabel:SetTextColor(EDITOR_COLORS.text)
    questCompleteLabel:SetFont("StalkerEditorText")

    local questCompleteEntry = vgui.Create("DTextEntry", container)
    questCompleteEntry:Dock(TOP)
    questCompleteEntry:DockMargin(4, 0, 4, 4)
    questCompleteEntry:SetTall(24)
    questCompleteEntry:SetValue(node.quest_complete or "")
    questCompleteEntry:SetTextColor(EDITOR_COLORS.text)
    questCompleteEntry:SetCursorColor(EDITOR_COLORS.accent)
    questCompleteEntry.Paint = PaintInputBg
    questCompleteEntry.OnChange = function(pnl)
        local val = pnl:GetValue()
        node.quest_complete = val != "" and val or nil
    end

    -- Озвучка
    local soundLabel = vgui.Create("DLabel", container)
    soundLabel:Dock(TOP)
    soundLabel:DockMargin(4, 4, 4, 2)
    soundLabel:SetText("Звук реплики (пусто = без звука):")
    soundLabel:SetTextColor(EDITOR_COLORS.text)
    soundLabel:SetFont("StalkerEditorText")

    local soundEntry = vgui.Create("DTextEntry", container)
    soundEntry:Dock(TOP)
    soundEntry:DockMargin(4, 0, 4, 4)
    soundEntry:SetTall(24)
    soundEntry:SetValue(node.sound or "")
    soundEntry:SetPlaceholderText("vo/npc/hello.wav")
    soundEntry:SetTextColor(EDITOR_COLORS.text)
    soundEntry:SetCursorColor(EDITOR_COLORS.accent)
    soundEntry.Paint = PaintInputBg
    soundEntry.OnChange = function(pnl)
        local val = pnl:GetValue()
        node.sound = val != "" and val or nil
    end

    -- Условия узла
    local condLabel = vgui.Create("DLabel", container)
    condLabel:Dock(TOP)
    condLabel:DockMargin(4, 8, 4, 2)
    condLabel:SetText("Условия показа узла:")
    condLabel:SetTextColor(EDITOR_COLORS.accent)
    condLabel:SetFont("StalkerEditorTitle")

    node.conditions = node.conditions or {}

    local firstTalkCheck = vgui.Create("DCheckBoxLabel", container)
    firstTalkCheck:Dock(TOP)
    firstTalkCheck:DockMargin(4, 4, 4, 2)
    firstTalkCheck:SetText("Только первый разговор")
    firstTalkCheck:SetTextColor(EDITOR_COLORS.text)
    firstTalkCheck:SetValue(node.conditions.first_talk_only or false)
    firstTalkCheck.OnChange = function(_, val)
        node.conditions.first_talk_only = val
    end

    local notFirstCheck = vgui.Create("DCheckBoxLabel", container)
    notFirstCheck:Dock(TOP)
    notFirstCheck:DockMargin(4, 2, 4, 2)
    notFirstCheck:SetText("Только повторные разговоры")
    notFirstCheck:SetTextColor(EDITOR_COLORS.text)
    notFirstCheck:SetValue(node.conditions.not_first_talk or false)
    notFirstCheck.OnChange = function(_, val)
        node.conditions.not_first_talk = val
    end

    local questActiveLabel = vgui.Create("DLabel", container)
    questActiveLabel:Dock(TOP)
    questActiveLabel:DockMargin(4, 4, 4, 2)
    questActiveLabel:SetText("Показать если квест активен (ID):")
    questActiveLabel:SetTextColor(EDITOR_COLORS.text)

    local questActiveEntry = vgui.Create("DTextEntry", container)
    questActiveEntry:Dock(TOP)
    questActiveEntry:DockMargin(4, 0, 4, 2)
    questActiveEntry:SetTall(24)
    questActiveEntry:SetValue(node.conditions.quest_active or "")
    questActiveEntry:SetTextColor(EDITOR_COLORS.text)
    questActiveEntry.Paint = PaintInputBg
    questActiveEntry.OnChange = function(pnl)
        local val = pnl:GetValue()
        node.conditions.quest_active = val != "" and val or nil
    end

    local questNotLabel = vgui.Create("DLabel", container)
    questNotLabel:Dock(TOP)
    questNotLabel:DockMargin(4, 4, 4, 2)
    questNotLabel:SetText("Показать если квест НЕ взят (ID):")
    questNotLabel:SetTextColor(EDITOR_COLORS.text)

    local questNotEntry = vgui.Create("DTextEntry", container)
    questNotEntry:Dock(TOP)
    questNotEntry:DockMargin(4, 0, 4, 4)
    questNotEntry:SetTall(24)
    questNotEntry:SetValue(node.conditions.quest_not_taken or "")
    questNotEntry:SetTextColor(EDITOR_COLORS.text)
    questNotEntry.Paint = PaintInputBg
    questNotEntry.OnChange = function(pnl)
        local val = pnl:GetValue()
        node.conditions.quest_not_taken = val != "" and val or nil
    end

    local sep = vgui.Create("DPanel", container)
    sep:Dock(TOP)
    sep:SetTall(2)
    sep:DockMargin(4, 8, 4, 8)
    sep.Paint = function(pnl, w, h)
        surface.SetDrawColor(EDITOR_COLORS.border)
        surface.DrawRect(0, 0, w, h)
    end

    local optionsHeader = vgui.Create("DLabel", container)
    optionsHeader:Dock(TOP)
    optionsHeader:DockMargin(4, 4, 4, 4)
    optionsHeader:SetText("Варианты ответов:")
    optionsHeader:SetTextColor(EDITOR_COLORS.accent)
    optionsHeader:SetFont("StalkerEditorTitle")

    node.options = node.options or {}

    for i, option in ipairs(node.options) do
        local optPanel = vgui.Create("DPanel", container)
        optPanel:Dock(TOP)
        optPanel:SetTall(80)
        optPanel:DockMargin(4, 4, 4, 4)
        optPanel.Paint = function(pnl, w, h)
            surface.SetDrawColor(Color(35, 32, 26))
            surface.DrawRect(0, 0, w, h)
            surface.SetDrawColor(EDITOR_COLORS.border)
            surface.DrawOutlinedRect(0, 0, w, h, 1)
            draw.SimpleText("Вариант #" .. i, "StalkerEditorText", 6, 4, EDITOR_COLORS.accent, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        end

        local textEntry = vgui.Create("DTextEntry", optPanel)
        textEntry:SetPos(6, 24)
        textEntry:SetSize(300, 22)
        textEntry:SetValue(option.text or "")
        textEntry:SetTextColor(EDITOR_COLORS.text)
        textEntry:SetCursorColor(EDITOR_COLORS.accent)
        textEntry:SetPlaceholderText("Текст варианта...")
        textEntry.Paint = PaintInputBg
        textEntry.OnChange = function(pnl)
            option.text = pnl:GetValue()
        end

        local nextLabel = vgui.Create("DLabel", optPanel)
        nextLabel:SetPos(6, 50)
        nextLabel:SetSize(70, 22)
        nextLabel:SetText("Переход к:")
        nextLabel:SetTextColor(EDITOR_COLORS.text)
        nextLabel:SetFont("StalkerEditorText")

        local nextEntry = vgui.Create("DTextEntry", optPanel)
        nextEntry:SetPos(80, 50)
        nextEntry:SetSize(226, 22)
        nextEntry:SetValue(option.next or "exit")
        nextEntry:SetTextColor(EDITOR_COLORS.text)
        nextEntry:SetCursorColor(EDITOR_COLORS.accent)
        nextEntry:SetPlaceholderText("ID узла, 'exit' или 'open_trade'")
        nextEntry.Paint = PaintInputBg
        nextEntry.OnChange = function(pnl)
            option.next = pnl:GetValue()
        end

        local delBtn = vgui.Create("DButton", optPanel)
        delBtn:SetPos(320, 24)
        delBtn:SetSize(60, 22)
        delBtn:SetText("Удалить")
        delBtn:SetTextColor(EDITOR_COLORS.red)
        delBtn.Paint = PaintButton
        delBtn.DoClick = function()
            table.remove(node.options, i)
            self:EditNode(nodeID, container, scroll, refreshFunc)
        end
    end

    local addOptBtn = vgui.Create("DButton", container)
    addOptBtn:Dock(TOP)
    addOptBtn:SetTall(30)
    addOptBtn:DockMargin(4, 4, 4, 4)
    addOptBtn:SetText("+ Добавить вариант ответа")
    addOptBtn:SetTextColor(EDITOR_COLORS.green)
    addOptBtn.Paint = function(pnl, w, h)
        surface.SetDrawColor(pnl:IsHovered() and EDITOR_COLORS.button_hover or EDITOR_COLORS.button)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(EDITOR_COLORS.border)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    addOptBtn.DoClick = function()
        table.insert(node.options, {text = "Новый вариант", next = "exit"})
        self:EditNode(nodeID, container, scroll, refreshFunc)
    end
end

function StalkerEditor:BuildQuestTab(parent)
    local panel = vgui.Create("DPanel", parent)
    panel.Paint = function(pnl, w, h)
        surface.SetDrawColor(EDITOR_COLORS.bg)
        surface.DrawRect(0, 0, w, h)
    end

    local leftPanel = vgui.Create("DPanel", panel)
    leftPanel:Dock(LEFT)
    leftPanel:SetWide(200)
    leftPanel:DockMargin(4, 4, 4, 4)
    leftPanel.Paint = function(pnl, w, h)
        surface.SetDrawColor(EDITOR_COLORS.panel)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(EDITOR_COLORS.border)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
        draw.SimpleText("Квесты", "StalkerEditorText", w / 2, 10, EDITOR_COLORS.accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
    end

    local questList = vgui.Create("DListView", leftPanel)
    questList:Dock(FILL)
    questList:DockMargin(4, 28, 4, 4)
    questList:AddColumn("ID квеста")
    questList:SetMultiSelect(false)

    local rightPanel = vgui.Create("DPanel", panel)
    rightPanel:Dock(FILL)
    rightPanel:DockMargin(4, 4, 4, 4)
    rightPanel.Paint = function(pnl, w, h)
        surface.SetDrawColor(EDITOR_COLORS.panel)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(EDITOR_COLORS.border)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end

    local rightScroll = vgui.Create("DScrollPanel", rightPanel)
    rightScroll:Dock(FILL)
    rightScroll:DockMargin(4, 4, 4, 4)

    local questContainer = vgui.Create("DListLayout", rightScroll)
    questContainer:Dock(TOP)
    questContainer:DockMargin(4, 4, 4, 4)

    local function RefreshQuestList()
        questList:Clear()
        for questID, _ in pairs(self.Quests) do
            questList:AddLine(questID)
        end
    end

    RefreshQuestList()

    local btnPanel = vgui.Create("DPanel", leftPanel)
    btnPanel:Dock(BOTTOM)
    btnPanel:SetTall(70)
    btnPanel:DockMargin(4, 0, 4, 4)
    btnPanel.Paint = function() end

    local addQuestBtn = vgui.Create("DButton", btnPanel)
    addQuestBtn:Dock(TOP)
    addQuestBtn:SetTall(30)
    addQuestBtn:DockMargin(0, 2, 0, 2)
    addQuestBtn:SetText("+ Добавить квест")
    addQuestBtn:SetTextColor(EDITOR_COLORS.text)
    addQuestBtn.Paint = PaintButton
    addQuestBtn.DoClick = function()
        Derma_StringRequest("Новый квест", "Введите ID квеста:", "quest_" .. table.Count(self.Quests),
            function(text)
                if text == "" or self.Quests[text] then
                    notification.AddLegacy("ID уже существует или пустой!", NOTIFY_ERROR, 3)
                    return
                end
                self.Quests[text] = {
                    title = "Новый квест",
                    description = "Описание квеста",
                    objectives = {
                        {type = "talk_to", target = "any", required = 1, description = "Поговорить с NPC"}
                    },
                    rewards = {}
                }
                RefreshQuestList()
            end)
    end

    local delQuestBtn = vgui.Create("DButton", btnPanel)
    delQuestBtn:Dock(TOP)
    delQuestBtn:SetTall(30)
    delQuestBtn:DockMargin(0, 2, 0, 2)
    delQuestBtn:SetText("- Удалить квест")
    delQuestBtn:SetTextColor(EDITOR_COLORS.red)
    delQuestBtn.Paint = PaintButton
    delQuestBtn.DoClick = function()
        local _, selected = questList:GetSelectedLine()
        if selected then
            local questID = selected:GetValue(1)
            self.Quests[questID] = nil
            RefreshQuestList()
            questContainer:Clear()
        end
    end

    questList.OnRowSelected = function(lst, index, row)
        local questID = row:GetValue(1)
        self:EditQuest(questID, questContainer)
    end

    return panel
end

function StalkerEditor:EditQuest(questID, container)
    container:Clear()

    local quest = self.Quests[questID]
    if !quest then return end

    local header = vgui.Create("DLabel", container)
    header:Dock(TOP)
    header:DockMargin(4, 4, 4, 4)
    header:SetText("Редактирование квеста: " .. questID)
    header:SetTextColor(EDITOR_COLORS.accent)
    header:SetFont("StalkerEditorTitle")

    local titleLabel = vgui.Create("DLabel", container)
    titleLabel:Dock(TOP)
    titleLabel:DockMargin(4, 4, 4, 2)
    titleLabel:SetText("Название:")
    titleLabel:SetTextColor(EDITOR_COLORS.text)

    local titleEntry = vgui.Create("DTextEntry", container)
    titleEntry:Dock(TOP)
    titleEntry:DockMargin(4, 0, 4, 4)
    titleEntry:SetTall(24)
    titleEntry:SetValue(quest.title or "")
    titleEntry:SetTextColor(EDITOR_COLORS.text)
    titleEntry.Paint = PaintInputBg
    titleEntry.OnChange = function(pnl) quest.title = pnl:GetValue() end

    local descLabel = vgui.Create("DLabel", container)
    descLabel:Dock(TOP)
    descLabel:DockMargin(4, 4, 4, 2)
    descLabel:SetText("Описание:")
    descLabel:SetTextColor(EDITOR_COLORS.text)

    local descEntry = vgui.Create("DTextEntry", container)
    descEntry:Dock(TOP)
    descEntry:DockMargin(4, 0, 4, 4)
    descEntry:SetTall(60)
    descEntry:SetMultiline(true)
    descEntry:SetValue(quest.description or "")
    descEntry:SetTextColor(EDITOR_COLORS.text)
    descEntry.Paint = PaintInputBg
    descEntry.OnChange = function(pnl) quest.description = pnl:GetValue() end

    local sep = vgui.Create("DPanel", container)
    sep:Dock(TOP)
    sep:SetTall(2)
    sep:DockMargin(4, 8, 4, 8)
    sep.Paint = function(pnl, w, h)
        surface.SetDrawColor(EDITOR_COLORS.border)
        surface.DrawRect(0, 0, w, h)
    end

    local objHeader = vgui.Create("DLabel", container)
    objHeader:Dock(TOP)
    objHeader:DockMargin(4, 4, 4, 4)
    objHeader:SetText("Цели квеста:")
    objHeader:SetTextColor(EDITOR_COLORS.accent)
    objHeader:SetFont("StalkerEditorTitle")

    quest.objectives = quest.objectives or {}

    for i, obj in ipairs(quest.objectives) do
        local objPanel = vgui.Create("DPanel", container)
        objPanel:Dock(TOP)
        objPanel:SetTall(110)
        objPanel:DockMargin(4, 4, 4, 4)
        objPanel.Paint = function(pnl, w, h)
            surface.SetDrawColor(Color(35, 32, 26))
            surface.DrawRect(0, 0, w, h)
            surface.SetDrawColor(EDITOR_COLORS.border)
            surface.DrawOutlinedRect(0, 0, w, h, 1)
            draw.SimpleText("Цель #" .. i, "StalkerEditorText", 6, 4, EDITOR_COLORS.accent)
        end

        local typeCombo = vgui.Create("DComboBox", objPanel)
        typeCombo:SetPos(6, 24)
        typeCombo:SetSize(140, 22)
        typeCombo:AddChoice("kill", "kill")
        typeCombo:AddChoice("talk_to", "talk_to")
        typeCombo:AddChoice("collect", "collect")
        typeCombo:AddChoice("go_to", "go_to")
        typeCombo:SetValue(obj.type or "kill")
        typeCombo.OnSelect = function(_, _, val) obj.type = val end

        local targetLabel = vgui.Create("DLabel", objPanel)
        targetLabel:SetPos(160, 24)
        targetLabel:SetSize(50, 22)
        targetLabel:SetText("Цель:")
        targetLabel:SetTextColor(EDITOR_COLORS.text)

        local targetEntry = vgui.Create("DTextEntry", objPanel)
        targetEntry:SetPos(210, 24)
        targetEntry:SetSize(150, 22)
        targetEntry:SetValue(obj.target or "any")
        targetEntry:SetTextColor(EDITOR_COLORS.text)
        targetEntry.Paint = PaintInputBg
        targetEntry.OnChange = function(pnl) obj.target = pnl:GetValue() end

        local reqLabel = vgui.Create("DLabel", objPanel)
        reqLabel:SetPos(6, 52)
        reqLabel:SetSize(100, 22)
        reqLabel:SetText("Количество:")
        reqLabel:SetTextColor(EDITOR_COLORS.text)

        local reqEntry = vgui.Create("DNumberWang", objPanel)
        reqEntry:SetPos(110, 52)
        reqEntry:SetSize(80, 22)
        reqEntry:SetMin(1)
        reqEntry:SetMax(999)
        reqEntry:SetValue(obj.required or 1)
        reqEntry.OnValueChanged = function(pnl, val) obj.required = val end

        local objDescLabel = vgui.Create("DLabel", objPanel)
        objDescLabel:SetPos(6, 80)
        objDescLabel:SetSize(80, 22)
        objDescLabel:SetText("Описание:")
        objDescLabel:SetTextColor(EDITOR_COLORS.text)

        local objDescEntry = vgui.Create("DTextEntry", objPanel)
        objDescEntry:SetPos(90, 80)
        objDescEntry:SetSize(270, 22)
        objDescEntry:SetValue(obj.description or "")
        objDescEntry:SetTextColor(EDITOR_COLORS.text)
        objDescEntry.Paint = PaintInputBg
        objDescEntry.OnChange = function(pnl) obj.description = pnl:GetValue() end

        local delObjBtn = vgui.Create("DButton", objPanel)
        delObjBtn:SetPos(380, 24)
        delObjBtn:SetSize(60, 22)
        delObjBtn:SetText("Удалить")
        delObjBtn:SetTextColor(EDITOR_COLORS.red)
        delObjBtn.Paint = PaintButton
        delObjBtn.DoClick = function()
            table.remove(quest.objectives, i)
            self:EditQuest(questID, container)
        end
    end

    local addObjBtn = vgui.Create("DButton", container)
    addObjBtn:Dock(TOP)
    addObjBtn:SetTall(28)
    addObjBtn:DockMargin(4, 4, 4, 4)
    addObjBtn:SetText("+ Добавить цель")
    addObjBtn:SetTextColor(EDITOR_COLORS.green)
    addObjBtn.Paint = PaintButton
    addObjBtn.DoClick = function()
        table.insert(quest.objectives, {type = "kill", target = "any", required = 1, description = "Новая цель"})
        self:EditQuest(questID, container)
    end

    local sep2 = vgui.Create("DPanel", container)
    sep2:Dock(TOP)
    sep2:SetTall(2)
    sep2:DockMargin(4, 8, 4, 8)
    sep2.Paint = function(pnl, w, h)
        surface.SetDrawColor(EDITOR_COLORS.border)
        surface.DrawRect(0, 0, w, h)
    end

    local rewardHeader = vgui.Create("DLabel", container)
    rewardHeader:Dock(TOP)
    rewardHeader:DockMargin(4, 4, 4, 4)
    rewardHeader:SetText("Награды:")
    rewardHeader:SetTextColor(EDITOR_COLORS.accent)
    rewardHeader:SetFont("StalkerEditorTitle")

    quest.rewards = quest.rewards or {}

    for i, reward in ipairs(quest.rewards) do
        local rewPanel = vgui.Create("DPanel", container)
        rewPanel:Dock(TOP)
        rewPanel:SetTall(36)
        rewPanel:DockMargin(4, 2, 4, 2)
        rewPanel.Paint = function(pnl, w, h)
            surface.SetDrawColor(Color(35, 32, 26))
            surface.DrawRect(0, 0, w, h)
        end

        local typeCombo = vgui.Create("DComboBox", rewPanel)
        typeCombo:SetPos(6, 6)
        typeCombo:SetSize(100, 24)
        typeCombo:AddChoice("health")
        typeCombo:AddChoice("armor")
        typeCombo:AddChoice("weapon")
        typeCombo:AddChoice("ammo")
        typeCombo:AddChoice("money")
        typeCombo:SetValue(reward.type or "health")
        typeCombo.OnSelect = function(_, _, val) reward.type = val end

        local valEntry = vgui.Create("DTextEntry", rewPanel)
        valEntry:SetPos(116, 6)
        valEntry:SetSize(200, 24)
        valEntry:SetValue(reward.amount and tostring(reward.amount) or reward.class or "")
        valEntry:SetPlaceholderText("Кол-во или класс оружия")
        valEntry:SetTextColor(EDITOR_COLORS.text)
        valEntry.Paint = PaintInputBg
        valEntry.OnChange = function(pnl)
            local val = pnl:GetValue()
            if tonumber(val) then
                reward.amount = tonumber(val)
            else
                reward.class = val
            end
        end

        local delRewBtn = vgui.Create("DButton", rewPanel)
        delRewBtn:SetPos(326, 6)
        delRewBtn:SetSize(50, 24)
        delRewBtn:SetText("X")
        delRewBtn:SetTextColor(EDITOR_COLORS.red)
        delRewBtn.Paint = PaintButton
        delRewBtn.DoClick = function()
            table.remove(quest.rewards, i)
            self:EditQuest(questID, container)
        end
    end

    local addRewBtn = vgui.Create("DButton", container)
    addRewBtn:Dock(TOP)
    addRewBtn:SetTall(28)
    addRewBtn:DockMargin(4, 4, 4, 4)
    addRewBtn:SetText("+ Добавить награду")
    addRewBtn:SetTextColor(EDITOR_COLORS.green)
    addRewBtn.Paint = PaintButton
    addRewBtn.DoClick = function()
        table.insert(quest.rewards, {type = "health", amount = 25})
        self:EditQuest(questID, container)
    end
end

function StalkerEditor:BuildTradeTab(parent)
    local panel = vgui.Create("DPanel", parent)
    panel.Paint = function(pnl, w, h)
        surface.SetDrawColor(EDITOR_COLORS.bg)
        surface.DrawRect(0, 0, w, h)
    end

    local scroll = vgui.Create("DScrollPanel", panel)
    scroll:Dock(FILL)
    scroll:DockMargin(4, 4, 4, 4)

    local container = vgui.Create("DListLayout", scroll)
    container:Dock(TOP)
    container:DockMargin(4, 4, 4, 4)

    local function RebuildItems()
        container:Clear()

        local header = vgui.Create("DLabel", container)
        header:Dock(TOP)
        header:DockMargin(4, 4, 4, 4)
        header:SetText("Товары NPC (что можно купить у него):")
        header:SetTextColor(EDITOR_COLORS.accent)
        header:SetFont("StalkerEditorTitle")

        for i, item in ipairs(self.TradeItems) do
            local itemPanel = vgui.Create("DPanel", container)
            itemPanel:Dock(TOP)
            itemPanel:SetTall(150)
            itemPanel:DockMargin(4, 4, 4, 4)
            itemPanel.Paint = function(pnl, w, h)
                surface.SetDrawColor(Color(35, 32, 26))
                surface.DrawRect(0, 0, w, h)
                surface.SetDrawColor(EDITOR_COLORS.border)
                surface.DrawOutlinedRect(0, 0, w, h, 1)
                draw.SimpleText("Товар #" .. i, "StalkerEditorText", 6, 4, EDITOR_COLORS.accent)
            end

            local nameEntry = vgui.Create("DTextEntry", itemPanel)
            nameEntry:SetPos(6, 24)
            nameEntry:SetSize(200, 22)
            nameEntry:SetValue(item.name or "")
            nameEntry:SetPlaceholderText("Название")
            nameEntry:SetTextColor(EDITOR_COLORS.text)
            nameEntry.Paint = PaintInputBg
            nameEntry.OnChange = function(pnl) item.name = pnl:GetValue() end

            local typeCombo = vgui.Create("DComboBox", itemPanel)
            typeCombo:SetPos(220, 24)
            typeCombo:SetSize(100, 22)
            typeCombo:AddChoice("weapon")
            typeCombo:AddChoice("ammo")
            typeCombo:AddChoice("health")
            typeCombo:AddChoice("armor")
            typeCombo:AddChoice("entity")
            typeCombo:SetValue(item.type or "weapon")
            typeCombo.OnSelect = function(_, _, val) item.type = val end

            local classEntry = vgui.Create("DTextEntry", itemPanel)
            classEntry:SetPos(6, 52)
            classEntry:SetSize(200, 22)
            classEntry:SetValue(item.class or "")
            classEntry:SetPlaceholderText("Класс (weapon_ak47)")
            classEntry:SetTextColor(EDITOR_COLORS.text)
            classEntry.Paint = PaintInputBg
            classEntry.OnChange = function(pnl) item.class = pnl:GetValue() end

            local buyLabel = vgui.Create("DLabel", itemPanel)
            buyLabel:SetPos(6, 80)
            buyLabel:SetSize(100, 22)
            buyLabel:SetText("Цена покупки:")
            buyLabel:SetTextColor(EDITOR_COLORS.text)

            local buyEntry = vgui.Create("DNumberWang", itemPanel)
            buyEntry:SetPos(110, 80)
            buyEntry:SetSize(80, 22)
            buyEntry:SetMin(0)
            buyEntry:SetMax(999999)
            buyEntry:SetValue(item.buy_price or 100)
            buyEntry.OnValueChanged = function(pnl, val) item.buy_price = val end

            local sellLabel = vgui.Create("DLabel", itemPanel)
            sellLabel:SetPos(200, 80)
            sellLabel:SetSize(100, 22)
            sellLabel:SetText("Цена продажи:")
            sellLabel:SetTextColor(EDITOR_COLORS.text)

            local sellEntry = vgui.Create("DNumberWang", itemPanel)
            sellEntry:SetPos(310, 80)
            sellEntry:SetSize(80, 22)
            sellEntry:SetMin(0)
            sellEntry:SetMax(999999)
            sellEntry:SetValue(item.sell_price or 50)
            sellEntry.OnValueChanged = function(pnl, val) item.sell_price = val end

            local descEntry = vgui.Create("DTextEntry", itemPanel)
            descEntry:SetPos(6, 108)
            descEntry:SetSize(300, 22)
            descEntry:SetValue(item.description or "")
            descEntry:SetPlaceholderText("Описание товара")
            descEntry:SetTextColor(EDITOR_COLORS.text)
            descEntry.Paint = PaintInputBg
            descEntry.OnChange = function(pnl) item.description = pnl:GetValue() end

            local delBtn = vgui.Create("DButton", itemPanel)
            delBtn:SetPos(340, 24)
            delBtn:SetSize(60, 22)
            delBtn:SetText("Удалить")
            delBtn:SetTextColor(EDITOR_COLORS.red)
            delBtn.Paint = PaintButton
            delBtn.DoClick = function()
                table.remove(self.TradeItems, i)
                RebuildItems()
            end
        end

        local addBtn = vgui.Create("DButton", container)
        addBtn:Dock(TOP)
        addBtn:SetTall(30)
        addBtn:DockMargin(4, 8, 4, 4)
        addBtn:SetText("+ Добавить товар")
        addBtn:SetTextColor(EDITOR_COLORS.green)
        addBtn.Paint = PaintButton
        addBtn.DoClick = function()
            table.insert(self.TradeItems, {
                name = "Новый товар",
                type = "weapon",
                class = "weapon_pistol",
                buy_price = 100,
                sell_price = 50,
                description = ""
            })
            RebuildItems()
        end
    end

    RebuildItems()
    return panel
end

function StalkerEditor:Save()
    if !IsValid(self.NPC) then
        notification.AddLegacy("NPC больше не существует!", NOTIFY_ERROR, 3)
        return
    end

    local data = {
        dialogs = self.DialogNodes,
        quests = self.Quests
    }

    local json = util.TableToJSON(data)

    net.Start("stalker_save_dialogs")
        net.WriteEntity(self.NPC)
        net.WriteUInt(#json, 32)
        net.WriteData(json, #json)
    net.SendToServer()

    -- Сохраняем товары если NPC торговец
    if self.NPC:GetIsTrader() and self.TradeItems then
        local tradeJson = util.TableToJSON(self.TradeItems)

        net.Start("stalker_save_trade_data")
            net.WriteEntity(self.NPC)
            net.WriteUInt(#tradeJson, 32)
            net.WriteData(tradeJson, #tradeJson)
        net.SendToServer()
    end

    notification.AddLegacy("Данные сохранены!", NOTIFY_GENERIC, 3)
    surface.PlaySound("ui/buttonclickrelease.wav")
end

function StalkerEditor:Close()
    if IsValid(self.Panel) then
        self.Panel:Remove()
    end
    self.Panel = nil
end

net.Receive("stalker_open_editor", function()
    local npc = net.ReadEntity()
    local npcName = net.ReadString()
    local dataLen = net.ReadUInt(32)
    local jsonData = net.ReadData(dataLen)

    local json = tostring(jsonData)
    local data = {}
    if json and json != "" then
        data = util.JSONToTable(json) or {}
    end

    StalkerEditor:Open(npc, npcName, data)
end)