-- я заебался эту хуйню делать

StalkerDialogs = StalkerDialogs or {}
StalkerDialogs.PlayerHistory = StalkerDialogs.PlayerHistory or {}

function StalkerDialogs:GetHistory(ply, npc)
    if !IsValid(ply) or !IsValid(npc) then return {} end
    local sid = ply:SteamID64() or ply:SteamID()
    local npcID = npc:GetNPCName() .. "_" .. npc:EntIndex()

    self.PlayerHistory[sid] = self.PlayerHistory[sid] or {}
    self.PlayerHistory[sid][npcID] = self.PlayerHistory[sid][npcID] or {
        talk_count = 0,
        first_talk = false,
        completed_quests = {},
    }

    return self.PlayerHistory[sid][npcID]
end

function StalkerDialogs:IncrementTalkCount(ply, npc)
    local history = self:GetHistory(ply, npc)
    history.talk_count = history.talk_count + 1
    if history.talk_count == 1 then
        history.first_talk = true
    end
end

function StalkerDialogs:MarkQuestComplete(ply, questID)
    if !IsValid(ply) then return end
    local sid = ply:SteamID64() or ply:SteamID()

    self.PlayerHistory[sid] = self.PlayerHistory[sid] or {}
    for npcID, data in pairs(self.PlayerHistory[sid]) do
        data.completed_quests = data.completed_quests or {}
        data.completed_quests[questID] = true
    end
end

function StalkerDialogs:FilterDialogs(dialogs, ply, npc)
    if !dialogs then return {} end

    local history = self:GetHistory(ply, npc)
    local filtered = table.Copy(dialogs)

    for nodeID, node in pairs(filtered) do
        if node.conditions then
            local show = true

            if node.conditions.first_talk_only then
                if history.talk_count > 1 then
                    show = false
                end
            end

            if node.conditions.not_first_talk then
                if history.talk_count <= 1 then
                    show = false
                end
            end

            if node.conditions.quest_active then
                local questID = node.conditions.quest_active
                local playerQuests = StalkerQuests.PlayerQuests[ply:SteamID()] or {}
                if !playerQuests[questID] then
                    show = false
                end
            end

            if node.conditions.quest_completed then
                local questID = node.conditions.quest_completed
                local completed = history.completed_quests or {}
                if !completed[questID] then
                    show = false
                end
            end

            if node.conditions.quest_not_taken then
                local questID = node.conditions.quest_not_taken
                local playerQuests = StalkerQuests.PlayerQuests[ply:SteamID()] or {}
                if playerQuests[questID] then
                    show = false
                end
            end

            if node.conditions.min_talks then
                if history.talk_count < node.conditions.min_talks then
                    show = false
                end
            end

            if node.conditions.min_money then
                if StalkerMoney:Get(ply) < node.conditions.min_money then
                    show = false
                end
            end

            if !show then
                filtered[nodeID] = nil
            end
        end

        if node and node.options then
            local filteredOptions = {}
            for _, option in ipairs(node.options) do
                local showOpt = true

                if option.conditions then
                    if option.conditions.first_talk_only and history.talk_count > 1 then
                        showOpt = false
                    end
                    if option.conditions.not_first_talk and history.talk_count <= 1 then
                        showOpt = false
                    end
                    if option.conditions.quest_active then
                        local playerQuests = StalkerQuests.PlayerQuests[ply:SteamID()] or {}
                        if !playerQuests[option.conditions.quest_active] then
                            showOpt = false
                        end
                    end
                    if option.conditions.quest_completed then
                        local completed = history.completed_quests or {}
                        if !completed[option.conditions.quest_completed] then
                            showOpt = false
                        end
                    end
                    if option.conditions.quest_not_taken then
                        local playerQuests = StalkerQuests.PlayerQuests[ply:SteamID()] or {}
                        if playerQuests[option.conditions.quest_not_taken] then
                            showOpt = false
                        end
                    end
                    if option.conditions.min_money then
                        if StalkerMoney:Get(ply) < option.conditions.min_money then
                            showOpt = false
                        end
                    end
                end

                if showOpt then
                    table.insert(filteredOptions, option)
                end
            end
            node.options = filteredOptions
        end
    end

    return filtered
end

net.Receive("stalker_select_option", function(len, ply)
    local npc = net.ReadEntity()
    local optionID = net.ReadString()

    if !IsValid(npc) or npc:GetClass() != "stalker_npc" then return end
    if ply:GetPos():Distance(npc:GetPos()) > 300 then return end

    local dialogs = npc.Dialogs
    if !dialogs then return end
    if optionID == "open_trade" then
        if npc:GetIsTrader() then
            npc:OpenTrade(ply)
        else
            ply:ChatPrint("[STALKER] Этот NPC не торгует!")
        end
        return
    end

    if optionID == "exit" then return end
    if dialogs[optionID] then
        if dialogs[optionID].quest_start then
            StalkerQuests:StartQuest(ply, dialogs[optionID].quest_start, npc)
        end

        if dialogs[optionID].quest_complete then
            local completed = StalkerQuests:TryCompleteQuest(ply, dialogs[optionID].quest_complete, npc)
            if completed then
                StalkerDialogs:MarkQuestComplete(ply, dialogs[optionID].quest_complete)
            end
        end
    end
end)

net.Receive("stalker_save_dialogs", function(len, ply)
    if !ply:IsAdmin() then
        ply:ChatPrint("[STALKER] Только админы могут редактировать диалоги!")
        return
    end

    local npc = net.ReadEntity()
    local dataLen = net.ReadUInt(32)
    local jsonData = net.ReadData(dataLen)

    if !IsValid(npc) or npc:GetClass() != "stalker_npc" then return end

    local json = tostring(jsonData)
    local data = util.JSONToTable(json)

    if !data then
        ply:ChatPrint("[STALKER] Ошибка парсинга JSON!")
        return
    end

    if data.dialogs then
        npc:SetDialogData(data.dialogs)
    end

    if data.quests then
        npc:SetQuestData(data.quests)
        for questID, questData in pairs(data.quests) do
            StalkerQuests:RegisterQuest(questID, questData)
        end
    end

    StalkerSystem.NPCData[npc:EntIndex()] = StalkerSystem.NPCData[npc:EntIndex()] or {}
    StalkerSystem.NPCData[npc:EntIndex()].dialogs = data.dialogs or {}
    StalkerSystem.NPCData[npc:EntIndex()].quests = data.quests or {}

    ply:ChatPrint("[STALKER] Диалоги и квесты сохранены для NPC '" .. npc:GetNPCName() .. "'!")
end)