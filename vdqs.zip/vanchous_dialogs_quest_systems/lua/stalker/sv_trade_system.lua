-- УРААА!

StalkerTrade = StalkerTrade or {}

-- черный спи сок
StalkerTrade.SellBlacklist = {
    ["weapon_hands_sh"] = true,
    ["weapon_physgun"] = true,
    ["weapon_physcannon"] = true,
    ["gmod_tool"] = true,
    ["gmod_camera"] = true,
    ["weapon_fists"] = true,
}

net.Receive("stalker_buy_item", function(len, ply)
    local npc = net.ReadEntity()
    local itemIndex = net.ReadUInt(16)

    if !IsValid(npc) or npc:GetClass() != "stalker_npc" then return end
    if !npc:GetIsTrader() then return end
    if ply:GetPos():Distance(npc:GetPos()) > 300 then
        ply:ChatPrint("[STALKER] Слишком далеко!")
        return
    end

    local items = npc.TradeItems
    if !items or !items[itemIndex] then
        ply:ChatPrint("[STALKER] Товар не найден!")
        return
    end

    local item = items[itemIndex]
    local price = item.buy_price or 0
    local money = StalkerMoney:Get(ply)

    if money < price then
        net.Start("stalker_trade_result")
            net.WriteBool(false)
            net.WriteString("Недостаточно денег! Нужно: " .. price .. ", у вас: " .. money)
        net.Send(ply)
        return
    end

    if !StalkerMoney:Take(ply, price) then
        net.Start("stalker_trade_result")
            net.WriteBool(false)
            net.WriteString("Ошибка списания денег!")
        net.Send(ply)
        return
    end

    local itemType = item.type or "weapon"

    if itemType == "weapon" then
        ply:Give(item.class)
        if item.ammo_amount and item.ammo_type then
            ply:GiveAmmo(item.ammo_amount, item.ammo_type)
        end
    elseif itemType == "ammo" then
        ply:GiveAmmo(item.amount or 1, item.ammo_type or item.class)
    elseif itemType == "health" then
        ply:SetHealth(math.min(ply:Health() + (item.amount or 25), ply:GetMaxHealth()))
    elseif itemType == "armor" then
        ply:SetArmor(math.min(ply:Armor() + (item.amount or 25), 255))
    elseif itemType == "entity" then
        local ent = ents.Create(item.class)
        if IsValid(ent) then
            ent:SetPos(ply:GetPos() + ply:GetForward() * 50 + Vector(0, 0, 20))
            ent:Spawn()
        end
    end

    net.Start("stalker_trade_result")
        net.WriteBool(true)
        net.WriteString("Куплено: " .. (item.name or item.class))
    net.Send(ply)

    ply:ChatPrint("[STALKER] Куплено: " .. (item.name or item.class) .. " за " .. price .. " RU")
end)

net.Receive("stalker_sell_item", function(len, ply)
    local npc = net.ReadEntity()
    local weaponClass = net.ReadString()

    if !IsValid(npc) or npc:GetClass() != "stalker_npc" then return end
    if !npc:GetIsTrader() then return end
    if ply:GetPos():Distance(npc:GetPos()) > 300 then return end

    if StalkerTrade.SellBlacklist[weaponClass] then
        net.Start("stalker_trade_result")
            net.WriteBool(false)
            net.WriteString("Этот предмет нельзя продать!")
        net.Send(ply)
        return
    end

    local wep = ply:GetWeapon(weaponClass)
    if !IsValid(wep) then
        net.Start("stalker_trade_result")
            net.WriteBool(false)
            net.WriteString("У вас нет этого предмета!")
        net.Send(ply)
        return
    end

    local sellPrice = 0
    local itemName = weaponClass

    for _, item in ipairs(npc.TradeItems or {}) do
        if item.class == weaponClass then
            sellPrice = item.sell_price or math.floor((item.buy_price or 0) * 0.5)
            itemName = item.name or weaponClass
            break
        end
    end

    if sellPrice <= 0 then sellPrice = 50 end

    ply:StripWeapon(weaponClass)
    StalkerMoney:Add(ply, sellPrice)

    net.Start("stalker_trade_result")
        net.WriteBool(true)
        net.WriteString("Продано: " .. itemName .. " за " .. sellPrice .. " RU")
    net.Send(ply)

    ply:ChatPrint("[STALKER] Продано: " .. itemName .. " за " .. sellPrice .. " RU")
end)

net.Receive("stalker_save_trade_data", function(len, ply)
    if !ply:IsAdmin() then
        ply:ChatPrint("[STALKER] Только админы могут редактировать!")
        return
    end

    local npc = net.ReadEntity()
    local dataLen = net.ReadUInt(32)
    local jsonData = net.ReadData(dataLen)

    if !IsValid(npc) or npc:GetClass() != "stalker_npc" then return end

    local json = tostring(jsonData)
    local data = util.JSONToTable(json)

    if !data then
        ply:ChatPrint("[STALKER] Ошибка парсинга JSON!")
        return
    end

    npc:SetTradeData(data)
    ply:ChatPrint("[STALKER] Товары сохранены! (" .. #data .. " шт.)")
end)