-- Клиентская UI диалогов в стиле S.T.A.L.K.E.R. с озвучкой

StalkerDialogUI = StalkerDialogUI or {}
StalkerDialogUI.CurrentNPC = nil
StalkerDialogUI.CurrentDialogs = nil
StalkerDialogUI.CurrentNode = "root"
StalkerDialogUI.History = {}
StalkerDialogUI.Panel = nil
StalkerDialogUI.NPCName = "NPC"
StalkerDialogUI.PlayerName = "Player"
StalkerDialogUI.TalkCount = 0
StalkerDialogUI.CurrentSound = nil

local STALKER_COLORS = {
    bg = Color(20, 18, 15, 240),
    bg_dark = Color(12, 10, 8, 250),
    border = Color(120, 100, 60, 200),
    border_light = Color(160, 140, 80, 180),
    title_bg = Color(40, 35, 25, 230),
    text_npc_name = Color(255, 200, 80),
    text_player_name = Color(200, 180, 100),
    text_normal = Color(220, 210, 190),
    text_dim = Color(160, 150, 130),
    option_bg = Color(30, 26, 20, 200),
    option_hover = Color(60, 50, 35, 220),
    option_text = Color(220, 200, 150),
    scrollbar = Color(80, 70, 50),
}

surface.CreateFont("StalkerDialogTitle", {
    font = "Arial", size = 20, weight = 700, antialias = true,
})
surface.CreateFont("StalkerDialogText", {
    font = "Arial", size = 16, weight = 500, antialias = true,
})
surface.CreateFont("StalkerDialogOption", {
    font = "Arial", size = 15, weight = 500, antialias = true,
})

local function DrawStalkerBorder(x, y, w, h, borderColor)
    borderColor = borderColor or STALKER_COLORS.border
    surface.SetDrawColor(borderColor)
    surface.DrawOutlinedRect(x, y, w, h, 1)
    surface.DrawOutlinedRect(x + 1, y + 1, w - 2, h - 2, 1)

    local cs = 6
    surface.SetDrawColor(borderColor.r, borderColor.g, borderColor.b, 255)
    surface.DrawRect(x, y, cs, 2)
    surface.DrawRect(x, y, 2, cs)
    surface.DrawRect(x + w - cs, y, cs, 2)
    surface.DrawRect(x + w - 2, y, 2, cs)
    surface.DrawRect(x, y + h - 2, cs, 2)
    surface.DrawRect(x, y + h - cs, 2, cs)
    surface.DrawRect(x + w - cs, y + h - 2, cs, 2)
    surface.DrawRect(x + w - 2, y + h - cs, 2, cs)
end

function StalkerDialogUI:WrapText(text, font, maxWidth)
    surface.SetFont(font)
    local words = string.Explode(" ", text)
    local lines = {}
    local currentLine = ""

    for _, word in ipairs(words) do
        local testLine = currentLine == "" and word or (currentLine .. " " .. word)
        local tw = surface.GetTextSize(testLine)

        if tw > maxWidth and currentLine != "" then
            table.insert(lines, currentLine)
            currentLine = word
        else
            currentLine = testLine
        end
    end

    if currentLine != "" then
        table.insert(lines, currentLine)
    end

    return lines
end

-- Воспроизведение звука узла
function StalkerDialogUI:PlayNodeSound(node)
    -- Останавливаем предыдущий звук
    self:StopSound()

    if node and node.sound and node.sound != "" then
        self.CurrentSound = CreateSound(LocalPlayer(), node.sound)
        if self.CurrentSound then
            self.CurrentSound:Play()
        end
    end
end

function StalkerDialogUI:StopSound()
    if self.CurrentSound then
        self.CurrentSound:Stop()
        self.CurrentSound = nil
    end
end

function StalkerDialogUI:Open(npc, npcName, dialogs, startNode, talkCount)
    self:Close()

    self.CurrentNPC = npc
    self.CurrentDialogs = dialogs
    self.CurrentNode = startNode or "root"
    self.History = {}
    self.NPCName = npcName or "NPC"
    self.PlayerName = LocalPlayer():Nick()
    self.TalkCount = talkCount or 0

    if !self.CurrentDialogs[self.CurrentNode] then
        for nodeID, _ in pairs(self.CurrentDialogs) do
            self.CurrentNode = nodeID
            break
        end
    end

    gui.EnableScreenClicker(true)

    local scrW, scrH = ScrW(), ScrH()

    self.Panel = vgui.Create("DPanel")
    self.Panel:SetSize(scrW * 0.55, scrH * 0.7)
    self.Panel:Center()
    self.Panel:MakePopup()
    self.Panel:SetKeyboardInputEnabled(false)
    self.Panel.Paint = function(pnl, w, h)
        draw.RoundedBox(0, -scrW, -scrH, scrW * 3, scrH * 3, Color(0, 0, 0, 100))
        surface.SetDrawColor(STALKER_COLORS.bg)
        surface.DrawRect(0, 0, w, h)
        DrawStalkerBorder(0, 0, w, h, STALKER_COLORS.border)
        local divY = h * 0.65
        surface.SetDrawColor(STALKER_COLORS.border)
        surface.DrawLine(4, divY, w - 4, divY)
    end

    local node = self.CurrentDialogs[self.CurrentNode]
    if node and node.npc_text and node.npc_text != "" then
        table.insert(self.History, {
            speaker = self.NPCName,
            text = node.npc_text,
            is_player = false
        })
    end

    -- Озвучка первого узла
    self:PlayNodeSound(node)

    self:BuildDialog()
end

function StalkerDialogUI:BuildDialog()
    if !IsValid(self.Panel) then return end
    self.Panel:Clear()

    local w, h = self.Panel:GetSize()
    local dialogs = self.CurrentDialogs
    local node = dialogs[self.CurrentNode]

    if !node then
        self:Close()
        return
    end

    -- Заголовок NPC
    local titleBar = vgui.Create("DPanel", self.Panel)
    titleBar:SetPos(4, 4)
    titleBar:SetSize(w - 8, 30)
    titleBar.Paint = function(pnl, pw, ph)
        surface.SetDrawColor(STALKER_COLORS.title_bg)
        surface.DrawRect(0, 0, pw, ph)
        DrawStalkerBorder(0, 0, pw, ph, STALKER_COLORS.border_light)
        draw.SimpleText(self.NPCName, "StalkerDialogTitle", pw / 2, ph / 2, STALKER_COLORS.text_npc_name, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    -- История
    local historyScroll = vgui.Create("DScrollPanel", self.Panel)
    historyScroll:SetPos(8, 40)
    historyScroll:SetSize(w - 16, h * 0.60 - 44)

    local sbar = historyScroll:GetVBar()
    sbar:SetWide(6)
    sbar.Paint = function(_, pw, ph)
        surface.SetDrawColor(STALKER_COLORS.bg_dark)
        surface.DrawRect(0, 0, pw, ph)
    end
    sbar.btnUp.Paint = function() end
    sbar.btnDown.Paint = function() end
    sbar.btnGrip.Paint = function(_, pw, ph)
        surface.SetDrawColor(STALKER_COLORS.scrollbar)
        surface.DrawRect(0, 0, pw, ph)
    end

    local yPos = 4
    local maxWidth = w - 40

    for _, entry in ipairs(self.History) do
        local entryPanel = self:CreateHistoryEntry(historyScroll, entry, maxWidth)
        entryPanel:SetPos(4, yPos)
        yPos = yPos + entryPanel:GetTall() + 6
    end

    historyScroll:GetCanvas():SetTall(yPos + 10)

    timer.Simple(0.05, function()
        if IsValid(historyScroll) then
            sbar:SetScroll(yPos)
        end
    end)

    -- Заголовок игрока
    local playerTitleY = h * 0.62
    local playerTitle = vgui.Create("DPanel", self.Panel)
    playerTitle:SetPos(4, playerTitleY)
    playerTitle:SetSize(w - 8, 26)
    playerTitle.Paint = function(pnl, pw, ph)
        surface.SetDrawColor(STALKER_COLORS.title_bg)
        surface.DrawRect(0, 0, pw, ph)
        DrawStalkerBorder(0, 0, pw, ph, STALKER_COLORS.border_light)
        draw.SimpleText(self.PlayerName, "StalkerDialogTitle", pw / 2, ph / 2, STALKER_COLORS.text_player_name, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    -- Варианты
    local optionsScroll = vgui.Create("DScrollPanel", self.Panel)
    optionsScroll:SetPos(8, playerTitleY + 30)
    optionsScroll:SetSize(w - 16, h - playerTitleY - 38)

    local osbar = optionsScroll:GetVBar()
    osbar:SetWide(6)
    osbar.Paint = function(_, pw, ph)
        surface.SetDrawColor(STALKER_COLORS.bg_dark)
        surface.DrawRect(0, 0, pw, ph)
    end
    osbar.btnUp.Paint = function() end
    osbar.btnDown.Paint = function() end
    osbar.btnGrip.Paint = function(_, pw, ph)
        surface.SetDrawColor(STALKER_COLORS.scrollbar)
        surface.DrawRect(0, 0, pw, ph)
    end

    local optY = 4
    local hasExit = false

    if node.options then
        for i, option in ipairs(node.options) do
            if option.next == "exit" then hasExit = true end
            local optBtn = self:CreateOptionButton(optionsScroll, option, node)
            optBtn:SetPos(4, optY)
            optBtn:SetSize(w - 40, 30)
            optY = optY + 34
        end
    end

    if !hasExit then
        local exitBtn = self:CreateOptionButton(optionsScroll, {text = "До встречи.", next = "exit"}, node)
        exitBtn:SetPos(4, optY)
        exitBtn:SetSize(w - 40, 30)
        optY = optY + 34
    end

    optionsScroll:GetCanvas():SetTall(optY + 10)
end

function StalkerDialogUI:CreateOptionButton(parent, option, currentNode)
    local optBtn = vgui.Create("DButton", parent)
    optBtn:SetText("")
    optBtn:SetCursor("hand")

    optBtn.Paint = function(pnl, pw, ph)
        local bgCol = pnl:IsHovered() and STALKER_COLORS.option_hover or STALKER_COLORS.option_bg
        surface.SetDrawColor(bgCol)
        surface.DrawRect(0, 0, pw, ph)

        local textColor = pnl:IsHovered() and Color(255, 230, 150) or STALKER_COLORS.option_text
        draw.SimpleText(option.text, "StalkerDialogOption", 10, ph / 2, textColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end

    optBtn.DoClick = function()
        surface.PlaySound("ui/buttonclick.wav")
        self:OnOptionClick(option, currentNode)
    end

    return optBtn
end

function StalkerDialogUI:OnOptionClick(option, currentNode)
    local nextNode = option.next or "exit"

    table.insert(self.History, {
        speaker = self.PlayerName,
        text = option.text,
        is_player = true
    })

    net.Start("stalker_select_option")
        net.WriteEntity(self.CurrentNPC)
        net.WriteString(nextNode)
    net.SendToServer()

    -- Торговля
    if nextNode == "open_trade" then
        self:Close()
        return
    end

    -- Выход
    if nextNode == "exit" then
        timer.Simple(0.1, function()
            self:Close()
        end)
        return
    end

    -- Переход
    if self.CurrentDialogs[nextNode] then
        self.CurrentNode = nextNode

        local newNode = self.CurrentDialogs[nextNode]
        if newNode.npc_text and newNode.npc_text != "" then
            table.insert(self.History, {
                speaker = self.NPCName,
                text = newNode.npc_text,
                is_player = false
            })
        end

        -- Озвучка
        self:PlayNodeSound(newNode)

        self:BuildDialog()
    else
        self:Close()
    end
end

function StalkerDialogUI:CreateHistoryEntry(parent, entry, maxWidth)
    local lines = self:WrapText(entry.text, "StalkerDialogText", maxWidth - 20)
    local lineCount = #lines
    local totalH = 24 + (lineCount * 18) + 4

    local entryPanel = vgui.Create("DPanel", parent)
    entryPanel:SetSize(maxWidth, totalH)
    entryPanel:SetTall(totalH)

    entryPanel.Paint = function(pnl, pw, ph)
        local nameColor = entry.is_player and STALKER_COLORS.text_player_name or STALKER_COLORS.text_npc_name
        draw.SimpleText(entry.speaker, "StalkerDialogTitle", 6, 2, nameColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

        for i, line in ipairs(lines) do
            draw.SimpleText(line, "StalkerDialogText", 14, 22 + (i - 1) * 18, STALKER_COLORS.text_normal, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        end
    end

    return entryPanel
end

function StalkerDialogUI:Close()
    self:StopSound()

    if IsValid(self.Panel) then
        self.Panel:Remove()
    end
    self.Panel = nil
    self.CurrentNPC = nil
    self.CurrentDialogs = nil
    self.CurrentNode = "root"
    self.History = {}
    gui.EnableScreenClicker(false)
end

-- СЕТЬ
net.Receive("stalker_open_dialog", function()
    local npc = net.ReadEntity()
    local npcName = net.ReadString()
    local startNode = net.ReadString()
    local talkCount = net.ReadUInt(16)
    local dataLen = net.ReadUInt(32)
    local jsonData = net.ReadData(dataLen)

    local json = tostring(jsonData)
    local dialogs = util.JSONToTable(json)
    if !dialogs then return end

    StalkerDialogUI:Open(npc, npcName, dialogs, startNode, talkCount)
end)

net.Receive("stalker_close_dialog", function()
    StalkerDialogUI:Close()
end)

hook.Add("Think", "StalkerDialogEscapeClose", function()
    if StalkerDialogUI.Panel and IsValid(StalkerDialogUI.Panel) then
        if input.IsKeyDown(KEY_ESCAPE) then
            StalkerDialogUI:Close()
        end
    end
end)