-- рп дейстиве достал кубинскую сигару: пых пых пых

StalkerTradeUI = StalkerTradeUI or {}
StalkerTradeUI.SellBlacklist = {
    ["weapon_hands_sh"] = true,
    ["weapon_physgun"] = true,
    ["weapon_physcannon"] = true,
    ["gmod_tool"] = true,
    ["gmod_camera"] = true,
    ["weapon_keys"] = true,
}
StalkerTradeUI.Panel = nil
StalkerTradeUI.NPC = nil
StalkerTradeUI.Items = {}
StalkerTradeUI.PlayerMoney = 0

local TC = {
    bg = Color(18, 16, 13, 245),
    bg2 = Color(28, 25, 20, 240),
    panel = Color(35, 30, 24, 230),
    panel_light = Color(45, 40, 32, 220),
    border = Color(100, 85, 55, 200),
    border_light = Color(140, 120, 70, 180),
    accent = Color(200, 170, 70),
    gold = Color(255, 210, 80),
    text = Color(210, 200, 180),
    text_dim = Color(150, 140, 120),
    text_bright = Color(240, 230, 200),
    buy_btn = Color(50, 80, 40),
    buy_hover = Color(70, 110, 50),
    sell_btn = Color(80, 50, 40),
    sell_hover = Color(110, 70, 50),
    red = Color(200, 60, 60),
    green = Color(80, 200, 80),
    item_bg = Color(32, 28, 22, 220),
    item_hover = Color(50, 44, 34, 240),
    item_selected = Color(70, 60, 40, 240),
    header = Color(40, 35, 26, 240),
    money_bg = Color(25, 22, 18, 230),
    scrollbar = Color(70, 60, 45),
}

surface.CreateFont("StalkerTradeTitle", {
    font = "Arial", size = 20, weight = 700, antialias = true,
})
surface.CreateFont("StalkerTradeText", {
    font = "Arial", size = 15, weight = 500, antialias = true,
})
surface.CreateFont("StalkerTradeSmall", {
    font = "Arial", size = 13, weight = 500, antialias = true,
})
surface.CreateFont("StalkerTradeMoney", {
    font = "Arial", size = 18, weight = 700, antialias = true,
})
surface.CreateFont("StalkerTradePrice", {
    font = "Arial", size = 14, weight = 700, antialias = true,
})
surface.CreateFont("StalkerTradeBig", {
    font = "Arial", size = 24, weight = 700, antialias = true,
})

local function DrawBorder(x, y, w, h, col)
    col = col or TC.border
    surface.SetDrawColor(col)
    surface.DrawOutlinedRect(x, y, w, h, 1)

    local cs = 5
    surface.SetDrawColor(col.r, col.g, col.b, 255)
    surface.DrawRect(x, y, cs, 2)
    surface.DrawRect(x, y, 2, cs)
    surface.DrawRect(x + w - cs, y, cs, 2)
    surface.DrawRect(x + w - 2, y, 2, cs)
    surface.DrawRect(x, y + h - 2, cs, 2)
    surface.DrawRect(x, y + h - cs, 2, cs)
    surface.DrawRect(x + w - cs, y + h - 2, cs, 2)
    surface.DrawRect(x + w - 2, y + h - cs, 2, cs)
end

local function StyleScrollbar(scroll)
    local sb = scroll:GetVBar()
    sb:SetWide(6)
    sb.Paint = function(_, pw, ph)
        surface.SetDrawColor(TC.bg)
        surface.DrawRect(0, 0, pw, ph)
    end
    sb.btnUp.Paint = function() end
    sb.btnDown.Paint = function() end
    sb.btnGrip.Paint = function(_, pw, ph)
        surface.SetDrawColor(TC.scrollbar)
        surface.DrawRect(0, 0, pw, ph)
    end
end

function StalkerTradeUI:Open(npc, npcName, items)
    self:Close()

    self.NPC = npc
    self.NPCName = npcName
    self.Items = items or {}
    self.SelectedBuyItem = nil
    self.SelectedSellWeapon = nil

    gui.EnableScreenClicker(true)

    local scrW, scrH = ScrW(), ScrH()
    local pw, ph = scrW * 0.75, scrH * 0.8

    self.Panel = vgui.Create("DPanel")
    self.Panel:SetSize(pw, ph)
    self.Panel:Center()
    self.Panel:MakePopup()
    self.Panel:SetKeyboardInputEnabled(false)

    self.Panel.Paint = function(pnl, w, h)
-- ЗАТЕМНЕНИЕ ГОВНА, СДЕЛАТЬ ДРУГОЕ
-- Не сделал:(
        draw.RoundedBox(0, -scrW, -scrH, scrW * 3, scrH * 3, Color(0, 0, 0, 150))
        surface.SetDrawColor(TC.bg)
        surface.DrawRect(0, 0, w, h)
        DrawBorder(0, 0, w, h, TC.border)
    end

    self:BuildTradeUI()
end

function StalkerTradeUI:BuildTradeUI()
    if !IsValid(self.Panel) then return end
    self.Panel:Clear()

    local w, h = self.Panel:GetSize()
    local halfW = w * 0.48
    local margin = 6
    local buyPanel = vgui.Create("DPanel", self.Panel)
    buyPanel:SetPos(margin, margin)
    buyPanel:SetSize(halfW, h - margin * 2 - 50)
    buyPanel.Paint = function(pnl, pw, ph2)
        surface.SetDrawColor(TC.bg2)
        surface.DrawRect(0, 0, pw, ph2)
        DrawBorder(0, 0, pw, ph2, TC.border)
    end

    local buyHeader = vgui.Create("DPanel", buyPanel)
    buyHeader:SetPos(2, 2)
    buyHeader:SetSize(halfW - 4, 55)
    buyHeader.Paint = function(pnl, pw, ph2)
        surface.SetDrawColor(TC.header)
        surface.DrawRect(0, 0, pw, ph2)
        DrawBorder(0, 0, pw, ph2, TC.border_light)

        draw.SimpleText(self.NPCName, "StalkerTradeTitle", 10, 6, TC.gold, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        draw.SimpleText("Торговец", "StalkerTradeSmall", 10, 28, TC.text_dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        draw.SimpleText("∞ RU", "StalkerTradeMoney", pw - 10, 14, TC.green, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
    end

    local buyLabel = vgui.Create("DPanel", buyPanel)
    buyLabel:SetPos(2, 60)
    buyLabel:SetSize(halfW - 4, 26)
    buyLabel.Paint = function(pnl, pw, ph2)
        surface.SetDrawColor(TC.panel)
        surface.DrawRect(0, 0, pw, ph2)
        DrawBorder(0, 0, pw, ph2, TC.border)
        draw.SimpleText("Купить", "StalkerTradeTitle", pw / 2, ph2 / 2, TC.accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local buyScroll = vgui.Create("DScrollPanel", buyPanel)
    buyScroll:SetPos(2, 90)
    buyScroll:SetSize(halfW - 4, buyPanel:GetTall() - 92)
    StyleScrollbar(buyScroll)

    local buyY = 4
    for i, item in ipairs(self.Items) do
        local itemPanel = self:CreateBuyItem(buyScroll, item, i)
        itemPanel:SetPos(4, buyY)
        itemPanel:SetSize(halfW - 20, 70)
        buyY = buyY + 74
    end
    buyScroll:GetCanvas():SetTall(buyY + 10)

    local sellPanel = vgui.Create("DPanel", self.Panel)
    sellPanel:SetPos(w - halfW - margin, margin)
    sellPanel:SetSize(halfW, h - margin * 2 - 50)
    sellPanel.Paint = function(pnl, pw, ph2)
        surface.SetDrawColor(TC.bg2)
        surface.DrawRect(0, 0, pw, ph2)
        DrawBorder(0, 0, pw, ph2, TC.border)
    end

    local sellHeader = vgui.Create("DPanel", sellPanel)
    sellHeader:SetPos(2, 2)
    sellHeader:SetSize(halfW - 4, 55)
    sellHeader.Paint = function(pnl, pw, ph2)
        surface.SetDrawColor(TC.header)
        surface.DrawRect(0, 0, pw, ph2)
        DrawBorder(0, 0, pw, ph2, TC.border_light)

        draw.SimpleText(LocalPlayer():Nick(), "StalkerTradeTitle", 10, 6, TC.gold, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        draw.SimpleText("Сталкер", "StalkerTradeSmall", 10, 28, TC.text_dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

        draw.SimpleText(self.PlayerMoney .. " RU", "StalkerTradeMoney", pw - 10, 14, TC.green, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
    end

    local sellLabel = vgui.Create("DPanel", sellPanel)
    sellLabel:SetPos(2, 60)
    sellLabel:SetSize(halfW - 4, 26)
    sellLabel.Paint = function(pnl, pw, ph2)
        surface.SetDrawColor(TC.panel)
        surface.DrawRect(0, 0, pw, ph2)
        DrawBorder(0, 0, pw, ph2, TC.border)
        draw.SimpleText("Продать", "StalkerTradeTitle", pw / 2, ph2 / 2, TC.accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local sellScroll = vgui.Create("DScrollPanel", sellPanel)
    sellScroll:SetPos(2, 90)
    sellScroll:SetSize(halfW - 4, sellPanel:GetTall() - 92)
    StyleScrollbar(sellScroll)

    local sellY = 4
    local weapons = LocalPlayer():GetWeapons()
    for _, wep in ipairs(weapons) do
        if IsValid(wep) and !StalkerTradeUI.SellBlacklist[wep:GetClass()] then
            local sellItem = self:CreateSellItem(sellScroll, wep)
            sellItem:SetPos(4, sellY)
            sellItem:SetSize(halfW - 20, 60)
            sellY = sellY + 64
        end
    end
    sellScroll:GetCanvas():SetTall(sellY + 10)

    local exitBtn = vgui.Create("DButton", self.Panel)
    exitBtn:SetPos(w / 2 - 100, h - 42)
    exitBtn:SetSize(200, 36)
    exitBtn:SetText("")
    exitBtn:SetCursor("hand")
    exitBtn.Paint = function(pnl, bw, bh)
        local bgCol = pnl:IsHovered() and TC.sell_hover or TC.panel
        surface.SetDrawColor(bgCol)
        surface.DrawRect(0, 0, bw, bh)
        DrawBorder(0, 0, bw, bh, TC.border)
        draw.SimpleText("Выход", "StalkerTradeTitle", bw / 2, bh / 2, TC.text_bright, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    exitBtn.DoClick = function()
        surface.PlaySound("ui/buttonclick.wav")
        self:Close()
    end
end

function StalkerTradeUI:CreateBuyItem(parent, item, index)
    local panel = vgui.Create("DButton", parent)
    panel:SetText("")
    panel:SetCursor("hand")

    local isHovered = false

    panel.Paint = function(pnl, pw, ph)
        local bgCol = TC.item_bg
        if pnl:IsHovered() or pnl.Depressed then
            bgCol = TC.item_hover
        end
        surface.SetDrawColor(bgCol)
        surface.DrawRect(0, 0, pw, ph)
        DrawBorder(0, 0, pw, ph, Color(80, 70, 50, 150))

        local typeIcon = "?"
        local typeCol = TC.text_dim
        if item.type == "weapon" then
            typeIcon = "[W]"
            typeCol = Color(150, 180, 220)
        elseif item.type == "ammo" then
            typeIcon = "[A]"
            typeCol = Color(220, 200, 100)
        elseif item.type == "health" then
            typeIcon = "[+]"
            typeCol = Color(100, 220, 100)
        elseif item.type == "armor" then
            typeIcon = "[#]"
            typeCol = Color(100, 150, 220)
        elseif item.type == "entity" then
            typeIcon = "[E]"
            typeCol = Color(200, 150, 100)
        end

        draw.SimpleText(typeIcon, "StalkerTradeText", 8, 8, typeCol, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

        draw.SimpleText(item.name or item.class, "StalkerTradeText", 36, 8, TC.text_bright, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

        draw.SimpleText(item.class or "", "StalkerTradeSmall", 36, 28, TC.text_dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

        if item.description then
            draw.SimpleText(item.description, "StalkerTradeSmall", 36, 44, TC.text_dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        end

        local priceText = tostring(item.buy_price or 0) .. " RU"
        draw.SimpleText(priceText, "StalkerTradePrice", pw - 80, 10, TC.gold, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

        local btnX = pw - 75
        local btnY = 36
        local btnW2 = 66
        local btnH2 = 26

        local mx, my = pnl:CursorPos()
        local onBuyBtn = mx >= btnX and mx <= btnX + btnW2 and my >= btnY and my <= btnY + btnH2

        surface.SetDrawColor(onBuyBtn and TC.buy_hover or TC.buy_btn)
        surface.DrawRect(btnX, btnY, btnW2, btnH2)
        DrawBorder(btnX, btnY, btnW2, btnH2, TC.border)

        draw.SimpleText("Купить", "StalkerTradeSmall", btnX + btnW2 / 2, btnY + btnH2 / 2, TC.text_bright, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    panel.DoClick = function()
        surface.PlaySound("ui/buttonclick.wav")

        net.Start("stalker_buy_item")
            net.WriteEntity(self.NPC)
            net.WriteUInt(index, 16)
        net.SendToServer()
    end

    return panel
end

function StalkerTradeUI:CreateSellItem(parent, wep)
    local panel = vgui.Create("DButton", parent)
    panel:SetText("")
    panel:SetCursor("hand")

    local weaponClass = wep:GetClass()
    local weaponName = wep:GetPrintName() or wep.PrintName or weaponClass

    local sellPrice = 50
    for _, item in ipairs(self.Items) do
        if item.class == weaponClass then
            sellPrice = item.sell_price or math.floor((item.buy_price or 100) * 0.5)
            break
        end
    end

    panel.Paint = function(pnl, pw, ph)
        local bgCol = pnl:IsHovered() and TC.item_hover or TC.item_bg
        surface.SetDrawColor(bgCol)
        surface.DrawRect(0, 0, pw, ph)
        DrawBorder(0, 0, pw, ph, Color(80, 70, 50, 150))

        draw.SimpleText("[W]", "StalkerTradeText", 8, 8, Color(150, 180, 220), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        draw.SimpleText(weaponName, "StalkerTradeText", 36, 8, TC.text_bright, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        draw.SimpleText(weaponClass, "StalkerTradeSmall", 36, 28, TC.text_dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

        local priceText = sellPrice .. " RU"
        draw.SimpleText(priceText, "StalkerTradePrice", pw - 80, 10, TC.gold, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

        local btnX = pw - 75
        local btnY = 30
        local btnW2 = 66
        local btnH2 = 24

        surface.SetDrawColor(pnl:IsHovered() and TC.sell_hover or TC.sell_btn)
        surface.DrawRect(btnX, btnY, btnW2, btnH2)
        DrawBorder(btnX, btnY, btnW2, btnH2, TC.border)

        draw.SimpleText("Продать", "StalkerTradeSmall", btnX + btnW2 / 2, btnY + btnH2 / 2, TC.text_bright, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    panel.DoClick = function()
        surface.PlaySound("ui/buttonclick.wav")

        Derma_Query("Продать " .. weaponName .. " за " .. sellPrice .. " RU?", "Подтверждение",
            "Да", function()
                net.Start("stalker_sell_item")
                    net.WriteEntity(self.NPC)
                    net.WriteString(weaponClass)
                net.SendToServer()

                timer.Simple(0.3, function()
                    if IsValid(self.Panel) then
                        self:BuildTradeUI()
                    end
                end)
            end,
            "Нет", function() end
        )
    end

    return panel
end

function StalkerTradeUI:Close()
    if IsValid(self.Panel) then
        self.Panel:Remove()
    end
    self.Panel = nil
    self.NPC = nil
    self.Items = {}
    gui.EnableScreenClicker(false)
end


net.Receive("stalker_open_trade", function()
    local npc = net.ReadEntity()
    local npcName = net.ReadString()
    local dataLen = net.ReadUInt(32)
    local jsonData = net.ReadData(dataLen)

    local json = tostring(jsonData)
    local items = util.JSONToTable(json) or {}

    print("[STALKER Trade CL] Открытие торговли с " .. npcName .. ", товаров: " .. #items)

    StalkerTradeUI.PlayerMoney = StalkerMoneyHUD.Money or tonumber(LocalPlayer():GetNWString("WalletMoney", "0")) or 0

    StalkerTradeUI:Open(npc, npcName, items)
end)

net.Receive("stalker_trade_result", function()
    local success = net.ReadBool()
    local msg = net.ReadString()

    if success then
        notification.AddLegacy(msg, NOTIFY_GENERIC, 3)
    else
        notification.AddLegacy(msg, NOTIFY_ERROR, 3)
    end

    timer.Simple(0.3, function()
        if StalkerTradeUI.Panel and IsValid(StalkerTradeUI.Panel) then
            StalkerTradeUI:BuildTradeUI()
        end
    end)
end)

net.Receive("stalker_trade_data_update", function()
    StalkerTradeUI.PlayerMoney = net.ReadUInt(32)

    if StalkerTradeUI.Panel and IsValid(StalkerTradeUI.Panel) then
        StalkerTradeUI:BuildTradeUI()
    end
end)

hook.Add("Think", "StalkerTradeEscClose", function()
    if StalkerTradeUI.Panel and IsValid(StalkerTradeUI.Panel) then
        if input.IsKeyDown(KEY_ESCAPE) then
            StalkerTradeUI:Close()
        end
    end
end)