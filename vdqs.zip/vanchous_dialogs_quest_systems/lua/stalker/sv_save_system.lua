-- Я ниочем не жалею

StalkerSave = StalkerSave or {}
StalkerSave.SaveDir = "stalker_saves/"

function StalkerSave:GetMapFile()
    return self.SaveDir .. game.GetMap() .. ".txt"
end

function StalkerSave:Init()
    if !file.IsDir(self.SaveDir, "DATA") then
        file.CreateDir(self.SaveDir)
    end
end

function StalkerSave:SaveAll()
    self:Init()

    local npcs = {}

    for _, ent in ipairs(ents.FindByClass("stalker_npc")) do
        if IsValid(ent) then
            local data = {
                pos = {ent:GetPos().x, ent:GetPos().y, ent:GetPos().z},
                ang = {ent:GetAngles().p, ent:GetAngles().y, ent:GetAngles().r},
                name = ent:GetNPCName(),
                model = ent:GetNPCModel(),
                behavior = ent:GetBehaviorType(),
                immortal = ent:GetIsImmortal(),
                frozen = ent:GetIsFrozen(),
                trader = ent:GetIsTrader(),
                dialogs = ent.Dialogs or {},
                quests = ent.QuestGiver or {},
                trade_items = ent.TradeItems or {},
            }
            table.insert(npcs, data)
        end
    end

    local json = util.TableToJSON(npcs, true)
    file.Write(self:GetMapFile(), json)

    print("[STALKER Save] Сохранено NPC: " .. #npcs .. " на карте " .. game.GetMap())
    return #npcs
end

function StalkerSave:LoadAll()
    self:Init()

    local path = self:GetMapFile()
    if !file.Exists(path, "DATA") then
        print("[STALKER Save] Нет сохранения для карты " .. game.GetMap())
        return 0
    end

    local json = file.Read(path, "DATA")
    local npcs = util.JSONToTable(json)

    if !npcs then
        print("[STALKER Save] Ошибка чтения сохранения!")
        return 0
    end

    local count = 0
    for _, data in ipairs(npcs) do
        local npc = ents.Create("stalker_npc")
        if IsValid(npc) then
            npc:SetNPCName(data.name or "NPC")
            npc:SetNPCModel(data.model or "models/humans/group01/male_01.mdl")
            npc:SetBehaviorType(data.behavior or "stand")
            npc:SetIsImmortal(data.immortal or false)
            npc:SetIsFrozen(data.frozen or false)
            npc:SetIsTrader(data.trader or false)

            npc:SetPos(Vector(data.pos[1], data.pos[2], data.pos[3]))
            npc:SetAngles(Angle(data.ang[1], data.ang[2], data.ang[3]))

            npc:Spawn()
            npc:Activate()

            timer.Simple(0.2, function()
                if IsValid(npc) then
                    npc.Dialogs = data.dialogs or {}
                    npc.QuestGiver = data.quests or {}
                    npc.TradeItems = data.trade_items or {}

                    if data.quests then
                        for questID, questData in pairs(data.quests) do
                            StalkerQuests:RegisterQuest(questID, questData)
                        end
                    end
                end
            end)

            count = count + 1
        end
    end

    print("[STALKER Save] Загружено NPC: " .. count .. " на карте " .. game.GetMap())
    return count
end

function StalkerSave:Backup()
    self:Init()

    local backupDir = self.SaveDir .. "backups/"
    if !file.IsDir(backupDir, "DATA") then
        file.CreateDir(backupDir)
    end

    local path = self:GetMapFile()
    if !file.Exists(path, "DATA") then
        print("[STALKER Save] Нечего бэкапить!")
        return false
    end

    local content = file.Read(path, "DATA")
    local backupName = backupDir .. game.GetMap() .. "_" .. os.date("%Y%m%d_%H%M%S") .. ".txt"
    file.Write(backupName, content)

    print("[STALKER Save] Бэкап создан: " .. backupName)
    return true
end

function StalkerSave:DuplicateNPC(sourceNPC, pos, ang)
    if !IsValid(sourceNPC) then return nil end

    local npc = ents.Create("stalker_npc")
    if !IsValid(npc) then return nil end

    npc:SetNPCName(sourceNPC:GetNPCName())
    npc:SetNPCModel(sourceNPC:GetNPCModel())
    npc:SetBehaviorType(sourceNPC:GetBehaviorType())
    npc:SetIsImmortal(sourceNPC:GetIsImmortal())
    npc:SetIsFrozen(sourceNPC:GetIsFrozen())
    npc:SetIsTrader(sourceNPC:GetIsTrader())

    npc:SetPos(pos)
    npc:SetAngles(ang)
    npc:Spawn()
    npc:Activate()

    timer.Simple(0.2, function()
        if IsValid(npc) and IsValid(sourceNPC) then
            npc.Dialogs = table.Copy(sourceNPC.Dialogs or {})
            npc.QuestGiver = table.Copy(sourceNPC.QuestGiver or {})
            npc.TradeItems = table.Copy(sourceNPC.TradeItems or {})
        end
    end)

    return npc
end

hook.Add("PostCleanupMap", "StalkerAutoLoad", function()
    timer.Simple(2, function()
        StalkerSave:LoadAll()
    end)
end)

hook.Add("InitPostEntity", "StalkerFirstLoad", function()
    timer.Simple(3, function()
        StalkerSave:LoadAll()
    end)
end)

hook.Add("ShutDown", "StalkerSaveOnShutdown", function()
    StalkerSave:SaveAll()
end)

concommand.Add("stalker_save_npcs", function(ply)
    if IsValid(ply) and !ply:IsAdmin() then
        ply:ChatPrint("[STALKER] Только для админов!")
        return
    end

    local count = StalkerSave:SaveAll()
    local msg = "[STALKER] Сохранено " .. count .. " NPC"

    if IsValid(ply) then
        ply:ChatPrint(msg)
    end
    print(msg)
end)

concommand.Add("stalker_load_npcs", function(ply)
    if IsValid(ply) and !ply:IsAdmin() then
        ply:ChatPrint("[STALKER] Только для админов!")
        return
    end

    for _, ent in ipairs(ents.FindByClass("stalker_npc")) do
        if IsValid(ent) then ent:Remove() end
    end

    local count = StalkerSave:LoadAll()
    local msg = "[STALKER] Загружено " .. count .. " NPC"

    if IsValid(ply) then
        ply:ChatPrint(msg)
    end
    print(msg)
end)

concommand.Add("stalker_backup", function(ply)
    if IsValid(ply) and !ply:IsAdmin() then
        ply:ChatPrint("[STALKER] Только для админов!")
        return
    end

    StalkerSave:Backup()

    if IsValid(ply) then
        ply:ChatPrint("[STALKER] Бэкап создан!")
    end
end)

concommand.Add("stalker_clear_npcs", function(ply)
    if IsValid(ply) and !ply:IsAdmin() then
        ply:ChatPrint("[STALKER] Только для админов!")
        return
    end

    local count = 0
    for _, ent in ipairs(ents.FindByClass("stalker_npc")) do
        if IsValid(ent) then
            ent:Remove()
            count = count + 1
        end
    end

    if IsValid(ply) then
        ply:ChatPrint("[STALKER] Удалено " .. count .. " NPC")
    end
end)

print("[STALKER Save] Система сохранения загружена!")