-- я уже ничего не чувствую

StalkerQuests = StalkerQuests or {}
StalkerQuests.RegisteredQuests = StalkerQuests.RegisteredQuests or {}
StalkerQuests.PlayerQuests = StalkerQuests.PlayerQuests or {}

function StalkerQuests:RegisterQuest(questID, data)
    self.RegisteredQuests[questID] = {
        id = questID,
        title = data.title or "Без названия",
        description = data.description or "",
        objectives = data.objectives or {},
        rewards = data.rewards or {},
        on_complete_dialog = data.on_complete_dialog or nil,
    }
    print("[STALKER Quests] Registered quest: " .. questID)
end

function StalkerQuests:StartQuest(ply, questID, npc)
    if !IsValid(ply) then return end

    local quest = self.RegisteredQuests[questID]
    if !quest then
        ply:ChatPrint("[STALKER] Квест '" .. questID .. "' не найден!")
        return
    end

    self.PlayerQuests[ply:SteamID()] = self.PlayerQuests[ply:SteamID()] or {}

    if self.PlayerQuests[ply:SteamID()][questID] then
        ply:ChatPrint("[STALKER] Квест уже взят!")
        return
    end

    local progress = {}
    for i, obj in ipairs(quest.objectives) do
        progress[i] = {
            type = obj.type,
            target = obj.target,
            required = obj.required or 1,
            current = 0,
            completed = false,
            description = obj.description or ""
        }
    end

    self.PlayerQuests[ply:SteamID()][questID] = {
        id = questID,
        title = quest.title,
        description = quest.description,
        progress = progress,
        started = CurTime(),
        completed = false,
        npc_giver = IsValid(npc) and npc:EntIndex() or nil
    }

    net.Start("stalker_quest_start")
        net.WriteString(questID)
        net.WriteString(quest.title)
        net.WriteString(quest.description)
    net.Send(ply)

    for i, obj in ipairs(progress) do
        net.Start("stalker_quest_update")
            net.WriteString(questID)
            net.WriteUInt(i, 8)
            net.WriteUInt(obj.current, 16)
            net.WriteUInt(obj.required, 16)
            net.WriteBool(obj.completed)
            net.WriteString(obj.description)
        net.Send(ply)
    end

    ply:ChatPrint("[STALKER] Новый квест: " .. quest.title)
end

function StalkerQuests:CollectItemsFromPlayer(ply, itemClass, amount)
    local collected = 0
    
    for _, wep in ipairs(ply:GetWeapons()) do
        if IsValid(wep) and wep:GetClass() == itemClass then
            ply:StripWeapon(itemClass)
            collected = collected + 1
            if collected >= amount then
                return collected
            end
        end
    end
    
    local nearbyEnts = ents.FindInSphere(ply:GetPos(), 200)
    for _, ent in ipairs(nearbyEnts) do
        if IsValid(ent) and ent:GetClass() == itemClass then
            ent:Remove()
            collected = collected + 1
            if collected >= amount then
                return collected
            end
        end
    end
    
    return collected
end

function StalkerQuests:TryCompleteQuest(ply, questID, npc)
    if !IsValid(ply) then return end

    local playerData = self.PlayerQuests[ply:SteamID()]
    if !playerData or !playerData[questID] then
        ply:ChatPrint("[STALKER] У вас нет этого квеста!")
        return false
    end

    local questProgress = playerData[questID]

    for i, obj in ipairs(questProgress.progress) do
        if obj.completed then continue end
        
        if obj.type == "talk_to" then
            obj.current = obj.required
            obj.completed = true
            
            net.Start("stalker_quest_update")
                net.WriteString(questID)
                net.WriteUInt(i, 8)
                net.WriteUInt(obj.current, 16)
                net.WriteUInt(obj.required, 16)
                net.WriteBool(true)
                net.WriteString(obj.description)
            net.Send(ply)
        
        elseif obj.type == "collect" then
            local needed = obj.required - obj.current
            local collected = self:CollectItemsFromPlayer(ply, obj.target, needed)
            
            if collected > 0 then
                obj.current = obj.current + collected
                if obj.current >= obj.required then
                    obj.completed = true
                end
                
                ply:ChatPrint("[STALKER] Сдано предметов: " .. collected .. " (" .. obj.current .. "/" .. obj.required .. ")")
                
                net.Start("stalker_quest_update")
                    net.WriteString(questID)
                    net.WriteUInt(i, 8)
                    net.WriteUInt(obj.current, 16)
                    net.WriteUInt(obj.required, 16)
                    net.WriteBool(obj.completed)
                    net.WriteString(obj.description)
                net.Send(ply)
            end
        
        elseif obj.type == "go_to" then
            if IsValid(npc) and ply:GetPos():Distance(npc:GetPos()) < 300 then
                obj.current = obj.required
                obj.completed = true
                
                net.Start("stalker_quest_update")
                    net.WriteString(questID)
                    net.WriteUInt(i, 8)
                    net.WriteUInt(obj.current, 16)
                    net.WriteUInt(obj.required, 16)
                    net.WriteBool(true)
                    net.WriteString(obj.description)
                net.Send(ply)
            end
        end
    end

    local allDone = true
    local notDoneList = {}
    for i, obj in ipairs(questProgress.progress) do
        if !obj.completed then
            allDone = false
            table.insert(notDoneList, obj.description .. " (" .. obj.current .. "/" .. obj.required .. ")")
        end
    end

    if allDone then
        questProgress.completed = true

        local quest = self.RegisteredQuests[questID]
        if quest and quest.rewards then
            for _, reward in ipairs(quest.rewards) do
                if reward.type == "health" then
                    ply:SetHealth(math.min(ply:Health() + (reward.amount or 0), ply:GetMaxHealth()))
                    ply:ChatPrint("[STALKER] +" .. reward.amount .. " HP")
                elseif reward.type == "armor" then
                    ply:SetArmor(math.min(ply:Armor() + (reward.amount or 0), 255))
                    ply:ChatPrint("[STALKER] +" .. reward.amount .. " брони")
                elseif reward.type == "weapon" then
                    ply:Give(reward.class)
                    ply:ChatPrint("[STALKER] Получено оружие: " .. reward.class)
                elseif reward.type == "ammo" then
                    ply:GiveAmmo(reward.amount, reward.ammo_type or reward.class or "Pistol")
                    ply:ChatPrint("[STALKER] +" .. reward.amount .. " патронов")
                elseif reward.type == "money" then
                    StalkerMoney:Add(ply, reward.amount or 100)
                    ply:ChatPrint("[STALKER] +" .. (reward.amount or 100) .. " RU")
                end
            end 
        end 
-- БЛЯТЬ Я ЕБАЛ ЭТУ ХУЙНЮ ДЕЛАТЬ

        net.Start("stalker_quest_complete")
            net.WriteString(questID)
            net.WriteString(questProgress.title)
        net.Send(ply)

        ply:ChatPrint("[STALKER] Квест выполнен: " .. questProgress.title)

        playerData[questID] = nil
        return true
    else
        ply:ChatPrint("[STALKER] Квест ещё не выполнен:")
        for _, desc in ipairs(notDoneList) do
            ply:ChatPrint(" - " .. desc)
        end
        return false
    end
end

hook.Add("OnNPCKilled", "StalkerQuestKillTracker", function(npc, attacker, inflictor)
    if !IsValid(attacker) or !attacker:IsPlayer() then return end

    local steamID = attacker:SteamID()
    local playerQuests = StalkerQuests.PlayerQuests[steamID]
    if !playerQuests then return end

    for questID, quest in pairs(playerQuests) do
        if quest.completed then continue end

        for i, obj in ipairs(quest.progress) do
            if obj.completed then continue end
            if obj.type == "kill" then
                if obj.target == "any" or npc:GetClass() == obj.target then
                    obj.current = obj.current + 1
                    if obj.current >= obj.required then
                        obj.completed = true
                    end

                    net.Start("stalker_quest_update")
                        net.WriteString(questID)
                        net.WriteUInt(i, 8)
                        net.WriteUInt(obj.current, 16)
                        net.WriteUInt(obj.required, 16)
                        net.WriteBool(obj.completed)
                        net.WriteString(obj.description)
                    net.Send(attacker)
                end
            end
        end
    end
end)

hook.Add("PlayerDeath", "StalkerQuestPlayerKillTracker", function(victim, inflictor, attacker)
    if !IsValid(attacker) or !attacker:IsPlayer() or attacker == victim then return end

    local steamID = attacker:SteamID()
    local playerQuests = StalkerQuests.PlayerQuests[steamID]
    if !playerQuests then return end

    for questID, quest in pairs(playerQuests) do
        if quest.completed then continue end

        for i, obj in ipairs(quest.progress) do
            if obj.completed then continue end
            if obj.type == "kill" and (obj.target == "player" or obj.target == "any") then
                obj.current = obj.current + 1
                if obj.current >= obj.required then
                    obj.completed = true
                end

                net.Start("stalker_quest_update")
                    net.WriteString(questID)
                    net.WriteUInt(i, 8)
                    net.WriteUInt(obj.current, 16)
                    net.WriteUInt(obj.required, 16)
                    net.WriteBool(obj.completed)
                    net.WriteString(obj.description)
                net.Send(attacker)
            end
        end
    end
end)

concommand.Add("stalker_my_quests", function(ply)
    if !IsValid(ply) then return end
    local quests = StalkerQuests.PlayerQuests[ply:SteamID()]
    if !quests or table.Count(quests) == 0 then
        ply:ChatPrint("[STALKER] У вас нет активных квестов.")
        return
    end
    
    ply:ChatPrint("=== Ваши квесты ===")
    for qid, q in pairs(quests) do
        ply:ChatPrint("• " .. q.title)
        for i, obj in ipairs(q.progress) do
            local status = obj.completed and "✓" or "•"
            ply:ChatPrint("  " .. status .. " " .. obj.description .. " (" .. obj.current .. "/" .. obj.required .. ")")
        end
    end
end)