-- HUD денег + меню передачи денег

StalkerMoneyHUD = StalkerMoneyHUD or {}
StalkerMoneyHUD.Money = 0
StalkerMoneyHUD.MoneyDisplay = 0
StalkerMoneyHUD.LookingAt = nil
StalkerMoneyHUD.Notifications = {}
StalkerMoneyHUD.TransferPanel = nil

surface.CreateFont("StalkerMoneyHUD", {
    font = "Arial", size = 22, weight = 700, antialias = true,
})
surface.CreateFont("StalkerMoneyHUDSmall", {
    font = "Arial", size = 14, weight = 500, antialias = true,
})
surface.CreateFont("StalkerMoneyHint", {
    font = "Arial", size = 16, weight = 600, antialias = true,
})
surface.CreateFont("StalkerMoneyNotify", {
    font = "Arial", size = 24, weight = 700, antialias = true,
})

local MC = {
    bg = Color(18, 16, 13, 230),
    border = Color(120, 100, 60, 200),
    gold = Color(255, 210, 80),
    green = Color(80, 200, 80),
    red = Color(200, 80, 80),
    text = Color(220, 200, 160),
    text_dim = Color(160, 140, 100),
}

local function DrawBorder(x, y, w, h, col)
    col = col or MC.border
    surface.SetDrawColor(col)
    surface.DrawOutlinedRect(x, y, w, h, 1)
    local cs = 5
    surface.SetDrawColor(col.r, col.g, col.b, 255)
    surface.DrawRect(x, y, cs, 2)
    surface.DrawRect(x, y, 2, cs)
    surface.DrawRect(x + w - cs, y, cs, 2)
    surface.DrawRect(x + w - 2, y, 2, cs)
    surface.DrawRect(x, y + h - 2, cs, 2)
    surface.DrawRect(x, y + h - cs, 2, cs)
    surface.DrawRect(x + w - cs, y + h - 2, cs, 2)
    surface.DrawRect(x + w - 2, y + h - cs, 2, cs)
end

-- HUD баланса
hook.Add("HUDPaint", "StalkerMoneyHUDPaint", function()
    local ply = LocalPlayer()
    if !IsValid(ply) or !ply:Alive() then return end

    -- Плавное изменение отображаемой суммы
    StalkerMoneyHUD.MoneyDisplay = Lerp(FrameTime() * 8, StalkerMoneyHUD.MoneyDisplay, StalkerMoneyHUD.Money)

    local x = 20
    local y = ScrH() - 1050
    local w = 220
    local h = 48

    surface.SetDrawColor(MC.bg)
    surface.DrawRect(x, y, w, h)
    DrawBorder(x, y, w, h, MC.border)

    -- Иконка денег (просто символ)
    draw.SimpleText("₽", "StalkerMoneyHUD", x + 14, y + h / 2, MC.gold, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

    -- Сумма
    local moneyText = string.Comma(math.floor(StalkerMoneyHUD.MoneyDisplay)) .. " RU"
    draw.SimpleText(moneyText, "StalkerMoneyHUD", x + 30, y + 4, MC.gold, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
    draw.SimpleText("Баланс", "StalkerMoneyHUDSmall", x + 30, y + 28, MC.text_dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
end)

-- Уведомления (получение/трата денег)
hook.Add("HUDPaint", "StalkerMoneyNotifications", function()
    local toRemove = {}

    for i, notif in ipairs(StalkerMoneyHUD.Notifications) do
        local elapsed = CurTime() - notif.time
        local alpha = 255

        if elapsed < 0.3 then
            alpha = 255 * (elapsed / 0.3)
        elseif elapsed > notif.duration - 0.5 then
            alpha = 255 * ((notif.duration - elapsed) / 0.5)
        end

        if elapsed > notif.duration then
            table.insert(toRemove, i)
        else
            local yOffset = (i - 1) * 32
            local ny = ScrH() - 140 - yOffset

            draw.SimpleText(notif.text, "StalkerMoneyNotify", 30, ny, ColorAlpha(notif.color, alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end
    end

    for i = #toRemove, 1, -1 do
        table.remove(StalkerMoneyHUD.Notifications, toRemove[i])
    end
end)

function StalkerMoneyHUD:AddNotification(text, color, duration)
    table.insert(self.Notifications, {
        text = text,
        color = color or MC.gold,
        time = CurTime(),
        duration = duration or 3
    })
end

-- Подсказка при наведении на игрока
hook.Add("HUDPaint", "StalkerMoneyTransferHint", function()
    local ply = LocalPlayer()
    if !IsValid(ply) or !ply:Alive() then return end

    local tr = ply:GetEyeTrace()
    if !tr.Hit then return end

    local ent = tr.Entity
    if !IsValid(ent) or !ent:IsPlayer() or ent == ply then 
        StalkerMoneyHUD.LookingAt = nil
        return 
    end

    local dist = ply:GetPos():Distance(ent:GetPos())
    if dist > 300 then 
        StalkerMoneyHUD.LookingAt = nil
        return 
    end

    StalkerMoneyHUD.LookingAt = ent

    -- Рисуем подсказку по центру экрана внизу
    local x = ScrW() / 2
    local y = ScrH() * 0.6

    local hintText = "[F3] Передать деньги игроку " .. ent:Nick()
    surface.SetFont("StalkerMoneyHint")
    local tw, th = surface.GetTextSize(hintText)

    local boxW = tw + 30
    local boxH = th + 14

    surface.SetDrawColor(MC.bg)
    surface.DrawRect(x - boxW / 2, y, boxW, boxH)
    DrawBorder(x - boxW / 2, y, boxW, boxH, MC.border)

    draw.SimpleText(hintText, "StalkerMoneyHint", x, y + boxH / 2, MC.gold, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end)

-- Открытие меню передачи денег по F3
hook.Add("Think", "StalkerMoneyTransferKey", function()
    if !input.IsKeyDown(KEY_F3) then
        StalkerMoneyHUD.F3Pressed = false
        return
    end

    if StalkerMoneyHUD.F3Pressed then return end
    StalkerMoneyHUD.F3Pressed = true

    local target = StalkerMoneyHUD.LookingAt
    if !IsValid(target) or !target:IsPlayer() then return end

    StalkerMoneyHUD:OpenTransferMenu(target)
end)

-- Меню передачи денег
function StalkerMoneyHUD:OpenTransferMenu(target)
    if IsValid(self.TransferPanel) then self.TransferPanel:Remove() end

    if !IsValid(target) then return end

    local pnl = vgui.Create("DFrame")
    pnl:SetSize(380, 220)
    pnl:Center()
    pnl:MakePopup()
    pnl:SetTitle("")
    pnl:ShowCloseButton(false)
    pnl:SetDraggable(false)

    pnl.Paint = function(_, w, h)
        surface.SetDrawColor(MC.bg)
        surface.DrawRect(0, 0, w, h)
        DrawBorder(0, 0, w, h, MC.border)

        draw.SimpleText("ПЕРЕДАЧА ДЕНЕГ", "StalkerMoneyHUD", w / 2, 18, MC.gold, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText("Получатель: " .. target:Nick(), "StalkerMoneyHint", w / 2, 50, MC.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText("Ваш баланс: " .. self.Money .. " RU", "StalkerMoneyHUDSmall", w / 2, 72, MC.text_dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    self.TransferPanel = pnl

    -- Поле ввода суммы
    local entry = vgui.Create("DTextEntry", pnl)
    entry:SetPos(40, 100)
    entry:SetSize(300, 36)
    entry:SetFont("StalkerMoneyHUD")
    entry:SetText("")
    entry:SetPlaceholderText("Введите сумму...")
    entry:SetNumeric(true)
    entry:RequestFocus()
    entry.Paint = function(p, w, h)
        surface.SetDrawColor(Color(25, 22, 18))
        surface.DrawRect(0, 0, w, h)
        DrawBorder(0, 0, w, h, MC.border)
        p:DrawTextEntryText(MC.gold, MC.gold, MC.gold)
    end

    local function SendMoney()
        local amount = tonumber(entry:GetValue()) or 0
        if amount <= 0 then
            self:AddNotification("Неверная сумма!", MC.red, 2)
            return
        end

        if amount > self.Money then
            self:AddNotification("Недостаточно денег!", MC.red, 2)
            return
        end

        if !IsValid(target) then return end

        net.Start("stalker_money_transfer_request")
            net.WriteEntity(target)
            net.WriteUInt(amount, 32)
        net.SendToServer()

        pnl:Remove()
    end

    -- Кнопка передать
    local sendBtn = vgui.Create("DButton", pnl)
    sendBtn:SetPos(40, 150)
    sendBtn:SetSize(140, 40)
    sendBtn:SetText("")
    sendBtn.Paint = function(p, w, h)
        surface.SetDrawColor(p:IsHovered() and Color(60, 120, 50) or Color(40, 90, 35))
        surface.DrawRect(0, 0, w, h)
        DrawBorder(0, 0, w, h, MC.border)
        draw.SimpleText("Передать", "StalkerMoneyHint", w / 2, h / 2, MC.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    sendBtn.DoClick = SendMoney

    -- Enter тоже передаёт
    entry.OnEnter = SendMoney

    -- Отмена
    local cancelBtn = vgui.Create("DButton", pnl)
    cancelBtn:SetPos(200, 150)
    cancelBtn:SetSize(140, 40)
    cancelBtn:SetText("")
    cancelBtn.Paint = function(p, w, h)
        surface.SetDrawColor(p:IsHovered() and Color(120, 50, 40) or Color(90, 35, 30))
        surface.DrawRect(0, 0, w, h)
        DrawBorder(0, 0, w, h, MC.border)
        draw.SimpleText("Отмена", "StalkerMoneyHint", w / 2, h / 2, MC.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    cancelBtn.DoClick = function() pnl:Remove() end
end

-- === СЕТЬ ===

net.Receive("stalker_money_sync", function()
    local oldMoney = StalkerMoneyHUD.Money
    StalkerMoneyHUD.Money = net.ReadUInt(32)

    local diff = StalkerMoneyHUD.Money - oldMoney
    if diff > 0 and oldMoney > 0 then
        StalkerMoneyHUD:AddNotification("+" .. diff .. " RU", MC.green, 3)
    elseif diff < 0 then
        StalkerMoneyHUD:AddNotification(diff .. " RU", MC.red, 3)
    end
end)

net.Receive("stalker_money_received", function()
    local sender = net.ReadEntity()
    local amount = net.ReadUInt(32)

    local senderName = IsValid(sender) and sender:Nick() or "Кто-то"
    StalkerMoneyHUD:AddNotification("+" .. amount .. " RU от " .. senderName, MC.green, 5)
    surface.PlaySound("ui/buttonclickrelease.wav")
end)